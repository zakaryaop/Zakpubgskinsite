CREATE TABLE IF NOT EXISTS "admins" (
	"id" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name "admins_id_seq" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),
	"username" text NOT NULL,
	"password" text NOT NULL,
	CONSTRAINT "admins_username_unique" UNIQUE("username")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "login_attempts" (
	"id" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name "login_attempts_id_seq" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),
	"telegram_id" text NOT NULL,
	"ip" text NOT NULL,
	"device_id" text,
	"success" boolean DEFAULT false NOT NULL,
	"reason" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "members" (
	"id" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name "members_id_seq" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),
	"telegram_id" text NOT NULL,
	"plan" text NOT NULL,
	"country" text NOT NULL,
	"payment_method" text NOT NULL,
	"screenshot_url" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"expiry_date" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"referral_code" text,
	"referred_by" text,
	"expiry_notified" boolean DEFAULT false,
	"login_key" text,
	"telegram_chat_id" text,
	"bound_device_id" text,
	"last_login_ip" text,
	"last_login_at" timestamp,
	"blocked" boolean DEFAULT false,
	CONSTRAINT "members_referral_code_unique" UNIQUE("referral_code"),
	CONSTRAINT "members_login_key_unique" UNIQUE("login_key")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "secure_downloads" (
	"id" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name "secure_downloads_id_seq" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),
	"token" text NOT NULL,
	"member_id" integer NOT NULL,
	"file_name" text NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"expires_at" timestamp NOT NULL,
	"used" boolean DEFAULT false,
	CONSTRAINT "secure_downloads_token_unique" UNIQUE("token")
);
