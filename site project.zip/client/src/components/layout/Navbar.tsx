import { useState, useEffect, useRef, useCallback } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Crown, Sun, Moon, ShoppingCart } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/i18n";
import { useTheme } from "@/lib/theme";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();
  const { currentUser, setCurrentUser } = useStore();
  const { t } = useI18n();
  const { theme, toggleTheme } = useTheme();
  const logout = () => setCurrentUser(null);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        ticking = true;
        rafRef.current = requestAnimationFrame(() => {
          setScrolled(window.scrollY > 20);
          ticking = false;
        });
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
      cancelAnimationFrame(rafRef.current);
    };
  }, []);

  const navLinks = [
    { href: "/", label: t("nav.home") },
    { href: "/#vip-plans", label: t("nav.memberships") },
    { href: "/#features", label: t("nav.features") },
  ];

  return (
    <>
      <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${scrolled ? "bg-background/80 backdrop-blur-xl border-b border-border py-4" : "bg-transparent py-6"}`}>
        <div className="container mx-auto px-6 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center border border-primary/20 group-hover:border-primary/50 transition-all shadow-[0_0_15px_rgba(var(--primary),0.1)]">
              <Crown className="text-primary w-5 h-5" />
            </div>
            <span className="font-heading font-bold text-2xl tracking-tight text-foreground">
              ZakPubg<span className="text-primary">Skin</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-8 bg-card/40 px-8 py-2.5 rounded-full border border-border backdrop-blur-md">
            {navLinks.map((link) => (
              <a 
                key={link.label} 
                href={link.href}
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>
            
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={toggleTheme}
              className="w-9 h-9 flex items-center justify-center rounded-full bg-card border border-border text-foreground hover:bg-muted transition-colors"
              data-testid="button-theme-toggle"
              aria-label="Toggle theme"
            >
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <LanguageSwitcher />
            {currentUser ? (
              <div className="flex items-center gap-3">
                <Link href="/portal" className="smooth-button flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-full font-bold text-sm">
                  <Crown className="w-4 h-4" />
                  {t("nav.dashboard")}
                </Link>
                <button onClick={logout} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  {t("nav.logout")}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <a href="/#vip-plans" className="smooth-button flex items-center gap-2 bg-yellow-400 hover:bg-yellow-300 text-gray-900 px-5 py-2.5 rounded-full font-bold text-sm shadow-[0_0_14px_rgba(234,179,8,0.45)] transition-colors">
                  <ShoppingCart className="w-3.5 h-3.5" />
                  {t("nav.getVip")}
                </a>
              </div>
            )}
          </div>

          <button 
            className="md:hidden w-10 h-10 flex items-center justify-center rounded-full bg-card border border-border text-foreground"
            onClick={() => setIsOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </nav>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-[80%] max-w-sm bg-background border-l border-border z-50 p-6 flex flex-col shadow-2xl"
            >
              <div className="flex justify-between items-center mb-8">
                <span className="font-heading font-bold text-xl text-foreground">{t("nav.menu")}</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={toggleTheme}
                    className="w-10 h-10 flex items-center justify-center rounded-full bg-card border border-border text-foreground hover:bg-muted transition-colors"
                    data-testid="button-theme-toggle-mobile"
                    aria-label="Toggle theme"
                  >
                    {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                  </button>
                  <LanguageSwitcher />
                  <button onClick={() => setIsOpen(false)} className="w-10 h-10 flex items-center justify-center rounded-full bg-card border border-border text-foreground">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
              
              {currentUser ? (
                <div className="flex flex-col gap-3 mb-6">
                  <Link href="/portal" onClick={() => setIsOpen(false)} className="w-full text-center smooth-button flex items-center justify-center gap-2 bg-yellow-400 hover:bg-yellow-300 text-gray-900 px-6 py-4 rounded-xl font-bold text-lg transition-colors">
                    <Crown className="w-5 h-5" />
                    {t("nav.dashboard")}
                  </Link>
                  <button onClick={() => { logout(); setIsOpen(false); }} className="text-muted-foreground py-2 font-medium text-sm">
                    {t("nav.signOut")}
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-3 mb-6">
                  <a href="/#vip-plans" onClick={() => setIsOpen(false)} className="w-full text-center smooth-button flex items-center justify-center gap-2 bg-yellow-400 hover:bg-yellow-300 text-gray-900 px-6 py-4 rounded-xl font-bold text-lg transition-colors">
                    <ShoppingCart className="w-5 h-5" />
                    {t("nav.getVip")}
                  </a>
                </div>
              )}

              <div className="flex flex-col gap-2 pt-4 border-t border-border">
                {navLinks.map((link) => (
                  <a 
                    key={link.label} 
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className="text-lg font-medium text-muted-foreground hover:text-foreground hover:bg-muted/50 px-4 py-3 rounded-xl transition-all"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
