import { motion } from "framer-motion";
import { Link } from "wouter";
import { Lock, ArrowLeft } from "lucide-react";

const fadeUp = { initial: { opacity: 0, y: 20 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true } };

export default function Privacy() {
  return (
    <div className="min-h-screen pt-24 pb-10 px-6">
      <div className="container mx-auto max-w-3xl">
        <motion.div {...fadeUp}>
          <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm mb-8" data-testid="link-back-home">
            <ArrowLeft className="w-4 h-4" /> Back to Home
          </Link>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-2xl bg-green-500/10 flex items-center justify-center border border-green-500/20">
              <Lock className="w-7 h-7 text-green-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground font-heading" data-testid="text-privacy-title">Privacy Policy</h1>
              <p className="text-muted-foreground text-sm mt-1">Last updated: February 2026</p>
            </div>
          </div>
        </motion.div>

        <motion.div {...fadeUp} transition={{ delay: 0.1 }} className="glass-panel rounded-2xl p-8 md:p-10 space-y-8">
          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">1. Information We Collect</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">We collect minimal information required to provide our services:</p>
            <ul className="mt-3 space-y-2">
              <li className="text-muted-foreground text-sm flex items-start gap-2"><span className="text-primary mt-1">•</span> Telegram ID (used for account identification and login)</li>
              <li className="text-muted-foreground text-sm flex items-start gap-2"><span className="text-primary mt-1">•</span> Country selection (for regional pricing)</li>
              <li className="text-muted-foreground text-sm flex items-start gap-2"><span className="text-primary mt-1">•</span> Payment method and screenshot (for payment verification)</li>
              <li className="text-muted-foreground text-sm flex items-start gap-2"><span className="text-primary mt-1">•</span> Membership plan selection</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">2. How We Use Your Information</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">Your information is used solely for:</p>
            <ul className="mt-3 space-y-2">
              <li className="text-muted-foreground text-sm flex items-start gap-2"><span className="text-primary mt-1">•</span> Verifying your payment and activating membership</li>
              <li className="text-muted-foreground text-sm flex items-start gap-2"><span className="text-primary mt-1">•</span> Providing access to VIP content and services</li>
              <li className="text-muted-foreground text-sm flex items-start gap-2"><span className="text-primary mt-1">•</span> Communicating membership status via Telegram</li>
              <li className="text-muted-foreground text-sm flex items-start gap-2"><span className="text-primary mt-1">•</span> Tracking membership expiry dates</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">3. Data Storage & Security</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">All data is stored securely in encrypted databases. Payment screenshots are stored temporarily for verification purposes only. We use industry-standard security measures including encrypted connections (HTTPS), secure admin authentication with bcrypt hashing, and JWT token-based sessions.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">4. Data Sharing</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">We do not sell, trade, or share your personal information with third parties. Your data is only accessible to our admin team for payment verification and membership management purposes.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">5. Cookies & Tracking</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">We use minimal local storage to remember your language preference and login session. We do not use third-party tracking cookies or analytics services that collect personal data.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">6. Your Rights</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">You have the right to request access to, correction of, or deletion of your personal data at any time. To exercise these rights, please contact our support team on Telegram.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">7. Data Retention</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">We retain membership data for the duration of your active membership plus 30 days after expiry. Payment screenshots are retained for 90 days for dispute resolution. You may request early deletion by contacting support.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">8. Changes to This Policy</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">We may update this privacy policy periodically. Users will be notified of significant changes through our Telegram channel. Continued use of our services constitutes acceptance of the updated policy.</p>
          </section>

          <div className="pt-4 border-t border-border">
            <p className="text-muted-foreground text-xs">For privacy inquiries, contact us on <a href="https://t.me/Zaksite_bot" target="_blank" className="text-primary hover:underline">Telegram</a>.</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
