import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Check,
  X,
  ShieldAlert,
  Clock,
  CheckCircle,
  Users,
  Eye,
  RefreshCw,
  LogOut,
  Image as ImageIcon,
  BarChart3,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Globe,
  CreditCard,
  UserPlus,
  CalendarDays,
  Crown,
  AlertTriangle,
  XCircle,
  PieChart,
  Activity,
} from "lucide-react";
import { useStore } from "@/lib/store";
import {
  adminLogin,
  getPendingMembers,
  getActiveMembers,
  approveMember,
  rejectMember,
  getAdminStats,
} from "@/lib/api";
import type { Member } from "@/lib/store";

interface AdminStats {
  overview: {
    total: number;
    active: number;
    pending: number;
    rejected: number;
  };
  signups: { today: number; week: number; month: number };
  revenue: { total: number; week: number; month: number };
  plans: { "30-days": number; "60-days": number };
  countries: Record<string, number>;
  methods: Record<string, number>;
  recentSignups: {
    id: number;
    telegramId: string;
    plan: string;
    country: string;
    status: string;
    createdAt: string;
  }[];
}

export default function Admin() {
  const { adminToken, setAdminToken } = useStore();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<"dashboard" | "pending" | "active">(
    "dashboard",
  );
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const [pendingUsers, setPendingUsers] = useState<Member[]>([]);
  const [activeUsers, setActiveUsers] = useState<Member[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [actionLoading, setActionLoading] = useState<number | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const fetchData = useCallback(async () => {
    if (!adminToken) return;
    try {
      const [pendingRes, activeRes, statsRes] = await Promise.all([
        getPendingMembers(adminToken),
        getActiveMembers(adminToken),
        getAdminStats(adminToken),
      ]);
      setPendingUsers(pendingRes.members);
      setActiveUsers(activeRes.members);
      setStats(statsRes);
    } catch {
      setAdminToken(null);
    }
  }, [adminToken, setAdminToken]);

  useEffect(() => {
    if (adminToken) {
      fetchData();
      const interval = setInterval(fetchData, 30000);
      return () => clearInterval(interval);
    }
  }, [adminToken, fetchData]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const result = await adminLogin(username, password);
      setAdminToken(result.token);
    } catch {
      setError("Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setTimeout(() => setRefreshing(false), 600);
  };

  const handleApprove = async (id: number) => {
    if (!adminToken) return;
    setActionLoading(id);
    try {
      await approveMember(id, adminToken);
      await fetchData();
    } catch (err) {
      console.error("Failed to approve:", err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleReject = async (id: number) => {
    if (!adminToken) return;
    setActionLoading(id);
    try {
      await rejectMember(id, adminToken);
      await fetchData();
    } catch (err) {
      console.error("Failed to reject:", err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleUnblock = async (id: number) => {
    if (!adminToken) return;
    setActionLoading(id);
    try {
      await fetch(`/api/admin/unblock/${id}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      await fetchData();
    } catch (err) {
      console.error("Failed to unblock:", err);
    } finally {
      setActionLoading(null);
    }
  };

  if (!adminToken) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-red-900/10 via-background to-background"></div>
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="glass-panel p-8 md:p-10 rounded-2xl max-w-sm w-full border-red-500/20 relative z-10"
        >
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-red-500/10 flex items-center justify-center border border-red-500/20">
              <ShieldAlert className="w-8 h-8 text-red-500" />
            </div>
          </div>
          <h2
            className="text-2xl font-bold text-center text-foreground mb-2 font-heading"
            data-testid="text-admin-title"
          >
            Admin Portal
          </h2>
          <p className="text-center text-muted-foreground text-sm mb-8">
            Restricted access only
          </p>

          {error && (
            <div className="mb-4 bg-red-500/10 border border-red-500/20 rounded-xl p-3 text-red-400 text-sm text-center">
              {error}
            </div>
          )}

          <form onSubmit={handleLogin}>
            <div className="mb-4">
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-background border border-border rounded-xl py-3.5 px-4 text-center text-foreground focus:border-red-500 focus:outline-none focus:ring-1 focus:ring-red-500 transition-all"
                data-testid="input-admin-username"
                autoComplete="off"
              />
            </div>
            <div className="mb-5">
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-background border border-border rounded-xl py-3.5 px-4 text-center text-foreground tracking-[0.2em] focus:border-red-500 focus:outline-none focus:ring-1 focus:ring-red-500 transition-all"
                data-testid="input-admin-password"
              />
            </div>
            <button
              disabled={loading || !username || !password}
              className="smooth-button w-full bg-red-600 text-white py-3.5 rounded-xl font-bold tracking-wider disabled:opacity-50 hover:bg-red-500 transition-colors"
              data-testid="button-admin-login"
            >
              {loading ? "Verifying..." : "Authenticate"}
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  const displayUsers = tab === "pending" ? pendingUsers : activeUsers;

  const sortedCountries = stats
    ? Object.entries(stats.countries).sort((a, b) => b[1] - a[1])
    : [];
  const sortedMethods = stats
    ? Object.entries(stats.methods).sort((a, b) => b[1] - a[1])
    : [];
  const maxCountryVal = sortedCountries.length > 0 ? sortedCountries[0][1] : 1;
  const maxMethodVal = sortedMethods.length > 0 ? sortedMethods[0][1] : 1;

  const approvalRate = stats && stats.overview.total > 0
    ? Math.round((stats.overview.active / stats.overview.total) * 100)
    : 0;

  const revenueWeeklyTrend = stats && stats.revenue.month > 0
    ? Math.round((stats.revenue.week / (stats.revenue.month / 4)) * 100 - 100)
    : 0;

  const signupsTrend = stats && stats.signups.week > 0 && stats.signups.month > 0
    ? Math.round((stats.signups.week / (stats.signups.month / 4)) * 100 - 100)
    : 0;

  const dailySignups = (() => {
    if (!stats?.recentSignups) return [];
    const days: { label: string; count: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dayStr = date.toISOString().split("T")[0];
      const label = date.toLocaleDateString(undefined, { weekday: "short" });
      const count = stats.recentSignups.filter((s) => {
        const signupDay = new Date(s.createdAt).toISOString().split("T")[0];
        return signupDay === dayStr;
      }).length;
      days.push({ label, count });
    }
    return days;
  })();
  const maxDailySignup = Math.max(...dailySignups.map((d) => d.count), 1);

  const totalCountryMembers = sortedCountries.reduce((sum, [, c]) => sum + c, 0);
  const countryGradientStops = (() => {
    if (totalCountryMembers === 0) return "hsl(0 0% 30%) 0% 100%";
    const colors = ["#3b82f6", "#22c55e", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#ec4899", "#f97316"];
    let acc = 0;
    const stops: string[] = [];
    sortedCountries.slice(0, 8).forEach(([, count], i) => {
      const pct = (count / totalCountryMembers) * 100;
      stops.push(`${colors[i % colors.length]} ${acc}% ${acc + pct}%`);
      acc += pct;
    });
    if (acc < 100) {
      stops.push(`hsl(0 0% 30%) ${acc}% 100%`);
    }
    return stops.join(", ");
  })();

  return (
    <div className="min-h-screen pt-20 pb-8 px-4 container mx-auto max-w-6xl">
      <AnimatePresence>
        {previewImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
            onClick={() => setPreviewImage(null)}
          >
            <motion.img
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              src={previewImage}
              alt="Payment screenshot"
              className="max-w-full max-h-[85vh] rounded-2xl shadow-2xl border border-border object-contain"
            />
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-6 right-6 w-10 h-10 bg-white/10 backdrop-blur rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row justify-between items-start md:items-center mb-5 gap-4"
      >
        <div>
          <h1
            className="text-2xl md:text-3xl font-bold text-foreground mb-1 font-heading"
            data-testid="text-admin-heading"
          >
            Command Center
          </h1>
          <p className="text-muted-foreground text-sm">
            Manage VIP memberships and approvals
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleRefresh}
            className="p-2.5 rounded-xl bg-card border border-border text-muted-foreground hover:text-foreground hover:bg-card/30 transition-all"
            data-testid="button-refresh"
          >
            <RefreshCw
              className={`w-4 h-4 ${refreshing ? "animate-spin" : ""}`}
            />
          </button>
          <button
            onClick={() => setAdminToken(null)}
            className="p-2.5 rounded-xl bg-card border border-border text-muted-foreground hover:text-red-400 hover:bg-red-500/5 transition-all"
            data-testid="button-admin-logout"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </motion.div>

      <div className="flex gap-1 bg-card/40 p-1 rounded-xl border border-border mb-4">
        <button
          onClick={() => setTab("dashboard")}
          className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all ${
            tab === "dashboard"
              ? "bg-primary/10 text-primary border border-primary/20"
              : "text-muted-foreground hover:text-foreground"
          }`}
          data-testid="tab-dashboard"
        >
          <BarChart3 className="w-4 h-4" />
          Dashboard
        </button>
        <button
          onClick={() => setTab("pending")}
          className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all ${
            tab === "pending"
              ? "bg-yellow-500/10 text-yellow-500 border border-yellow-500/20"
              : "text-muted-foreground hover:text-foreground"
          }`}
          data-testid="tab-pending"
        >
          <Clock className="w-4 h-4" />
          Pending ({pendingUsers.length})
        </button>
        <button
          onClick={() => setTab("active")}
          className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-medium flex items-center justify-center gap-2 transition-all ${
            tab === "active"
              ? "bg-green-500/10 text-green-500 border border-green-500/20"
              : "text-muted-foreground hover:text-foreground"
          }`}
          data-testid="tab-active"
        >
          <CheckCircle className="w-4 h-4" />
          Active ({activeUsers.length})
        </button>
      </div>

      <AnimatePresence mode="wait">
        {tab === "dashboard" && stats && (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.2 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {[
                {
                  label: "Total Members",
                  value: stats.overview.total,
                  icon: Users,
                  color: "text-blue-400",
                  bg: "bg-blue-500/10 border-blue-500/20",
                },
                {
                  label: "Active",
                  value: stats.overview.active,
                  icon: CheckCircle,
                  color: "text-green-500",
                  bg: "bg-green-500/10 border-green-500/20",
                },
                {
                  label: "Pending",
                  value: stats.overview.pending,
                  icon: Clock,
                  color: "text-yellow-500",
                  bg: "bg-yellow-500/10 border-yellow-500/20",
                },
                {
                  label: "Rejected",
                  value: stats.overview.rejected,
                  icon: XCircle,
                  color: "text-red-400",
                  bg: "bg-red-500/10 border-red-500/20",
                },
                {
                  label: "Approval Rate",
                  value: `${approvalRate}%`,
                  icon: Activity,
                  color: approvalRate >= 70 ? "text-green-400" : approvalRate >= 40 ? "text-yellow-400" : "text-red-400",
                  bg: approvalRate >= 70 ? "bg-green-500/10 border-green-500/20" : approvalRate >= 40 ? "bg-yellow-500/10 border-yellow-500/20" : "bg-red-500/10 border-red-500/20",
                },
              ].map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={`p-4 rounded-xl border ${stat.bg}`}
                  data-testid={`stat-card-${stat.label.toLowerCase().replace(" ", "-")}`}
                >
                  <stat.icon className={`w-4 h-4 ${stat.color} mb-2`} />
                  <div
                    className="text-xl md:text-2xl font-bold text-foreground"
                    data-testid={`stat-${stat.label.toLowerCase().replace(" ", "-")}`}
                  >
                    {stat.value}
                  </div>
                  <div className="text-[10px] text-muted-foreground uppercase tracking-wider mt-0.5">
                    {stat.label}
                  </div>
                  {stat.label === "Approval Rate" && (
                    <div className="mt-2 h-1.5 bg-background/60 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${approvalRate}%` }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className={`h-full rounded-full ${approvalRate >= 70 ? "bg-green-500" : approvalRate >= 40 ? "bg-yellow-500" : "bg-red-500"}`}
                      />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="glass-panel rounded-2xl p-6 border-border"
              >
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-primary" />
                    <h3 className="font-bold text-foreground text-lg">Revenue</h3>
                  </div>
                  {revenueWeeklyTrend !== 0 && (
                    <div
                      className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold ${
                        revenueWeeklyTrend > 0
                          ? "bg-green-500/10 text-green-400"
                          : "bg-red-500/10 text-red-400"
                      }`}
                      data-testid="revenue-trend"
                    >
                      {revenueWeeklyTrend > 0 ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      {revenueWeeklyTrend > 0 ? "+" : ""}{revenueWeeklyTrend}%
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: "This Week", value: stats.revenue.week },
                    { label: "This Month", value: stats.revenue.month },
                    { label: "All Time", value: stats.revenue.total },
                  ].map((r) => (
                    <div
                      key={r.label}
                      className="bg-background/60 rounded-xl p-4 border border-border text-center"
                    >
                      <div
                        className="text-xl md:text-2xl font-bold text-primary"
                        data-testid={`revenue-${r.label.toLowerCase().replace(" ", "-")}`}
                      >
                        ${r.value}
                      </div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider mt-1">
                        {r.label}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 }}
                className="glass-panel rounded-2xl p-6 border-border"
              >
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-2">
                    <UserPlus className="w-5 h-5 text-blue-400" />
                    <h3 className="font-bold text-foreground text-lg">New Sign-ups</h3>
                  </div>
                  {signupsTrend !== 0 && (
                    <div
                      className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold ${
                        signupsTrend > 0
                          ? "bg-green-500/10 text-green-400"
                          : "bg-red-500/10 text-red-400"
                      }`}
                      data-testid="signups-trend"
                    >
                      {signupsTrend > 0 ? (
                        <TrendingUp className="w-3 h-3" />
                      ) : (
                        <TrendingDown className="w-3 h-3" />
                      )}
                      {signupsTrend > 0 ? "+" : ""}{signupsTrend}%
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: "Today", value: stats.signups.today },
                    { label: "This Week", value: stats.signups.week },
                    { label: "This Month", value: stats.signups.month },
                  ].map((s) => (
                    <div
                      key={s.label}
                      className="bg-background/60 rounded-xl p-4 border border-border text-center"
                    >
                      <div
                        className="text-xl md:text-2xl font-bold text-blue-400"
                        data-testid={`signups-${s.label.toLowerCase().replace(" ", "-")}`}
                      >
                        {s.value}
                      </div>
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wider mt-1">
                        {s.label}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.18 }}
              className="glass-panel rounded-2xl p-6 border-border"
              data-testid="chart-daily-signups"
            >
              <div className="flex items-center gap-2 mb-5">
                <BarChart3 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-foreground text-lg">Signups — Last 7 Days</h3>
              </div>
              <div className="flex items-end gap-2 h-40">
                {dailySignups.map((day, i) => (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1 h-full justify-end">
                    <span className="text-xs font-bold text-foreground" data-testid={`bar-value-${i}`}>
                      {day.count > 0 ? day.count : ""}
                    </span>
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: day.count > 0 ? `${(day.count / maxDailySignup) * 100}%` : "4px" }}
                      transition={{ duration: 0.6, delay: i * 0.05, ease: "easeOut" }}
                      className={`w-full rounded-t-lg ${day.count > 0 ? "bg-gradient-to-t from-cyan-500 to-cyan-400" : "bg-border"}`}
                      style={{ minHeight: "4px" }}
                    />
                    <span className="text-[10px] text-muted-foreground mt-1">{day.label}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="glass-panel rounded-2xl p-6 border-border"
              >
                <div className="flex items-center gap-2 mb-5">
                  <Crown className="w-5 h-5 text-primary" />
                  <h3 className="font-bold text-foreground text-lg">
                    Plan Distribution
                  </h3>
                </div>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-muted-foreground font-medium">
                        VIP 30 Days ($14.99)
                      </span>
                      <span className="text-sm text-primary font-bold">
                        {stats.plans["30-days"]}
                      </span>
                    </div>
                    <div className="h-3 bg-background/60 rounded-full border border-border overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{
                          width: `${stats.overview.active > 0 ? (stats.plans["30-days"] / stats.overview.active) * 100 : 0}%`,
                        }}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                        className="h-full bg-gradient-to-r from-blue-500 to-blue-400 rounded-full"
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-muted-foreground font-medium">
                        VIP 60 Days ($24.99)
                      </span>
                      <span className="text-sm text-primary font-bold">
                        {stats.plans["60-days"]}
                      </span>
                    </div>
                    <div className="h-3 bg-background/60 rounded-full border border-border overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{
                          width: `${stats.overview.active > 0 ? (stats.plans["60-days"] / stats.overview.active) * 100 : 0}%`,
                        }}
                        transition={{
                          duration: 0.8,
                          ease: "easeOut",
                          delay: 0.1,
                        }}
                        className="h-full bg-gradient-to-r from-primary to-yellow-400 rounded-full"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.25 }}
                className="glass-panel rounded-2xl p-6 border-border"
              >
                <div className="flex items-center gap-2 mb-5">
                  <CreditCard className="w-5 h-5 text-purple-400" />
                  <h3 className="font-bold text-foreground text-lg">
                    Popular Payment Methods
                  </h3>
                </div>
                {sortedMethods.length === 0 ? (
                  <p className="text-muted-foreground text-sm text-center py-4">
                    No data yet
                  </p>
                ) : (
                  <div className="space-y-3 max-h-[200px] overflow-y-auto pr-1">
                    {sortedMethods.map(([method, count], i) => (
                      <div key={method}>
                        <div className="flex justify-between items-center mb-1.5">
                          <span className="text-sm text-muted-foreground font-medium truncate">
                            {method}
                          </span>
                          <span className="text-xs text-purple-400 font-bold shrink-0 ml-2">
                            {count}
                          </span>
                        </div>
                        <div className="h-2 bg-background/60 rounded-full border border-border overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{
                              width: `${(count / maxMethodVal) * 100}%`,
                            }}
                            transition={{ duration: 0.6, delay: i * 0.05 }}
                            className="h-full bg-gradient-to-r from-purple-500 to-purple-400 rounded-full"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="glass-panel rounded-2xl p-6 border-border"
                data-testid="chart-country-distribution"
              >
                <div className="flex items-center gap-2 mb-5">
                  <Globe className="w-5 h-5 text-green-400" />
                  <h3 className="font-bold text-foreground text-lg">
                    Top Countries
                  </h3>
                </div>
                {sortedCountries.length === 0 ? (
                  <p className="text-muted-foreground text-sm text-center py-4">
                    No data yet
                  </p>
                ) : (
                  <div className="flex gap-5">
                    <div
                      className="w-24 h-24 rounded-full shrink-0 border-2 border-border"
                      style={{ background: `conic-gradient(${countryGradientStops})` }}
                      data-testid="pie-chart-countries"
                    />
                    <div className="space-y-2 flex-1 max-h-[200px] overflow-y-auto pr-1">
                      {sortedCountries.map(([country, count], i) => {
                        const colors = ["bg-blue-500", "bg-green-500", "bg-yellow-500", "bg-red-500", "bg-purple-500", "bg-cyan-500", "bg-pink-500", "bg-orange-500"];
                        const pct = totalCountryMembers > 0 ? Math.round((count / totalCountryMembers) * 100) : 0;
                        return (
                          <div key={country} className="flex items-center gap-2">
                            <div className={`w-2.5 h-2.5 rounded-sm shrink-0 ${colors[i % colors.length]}`} />
                            <span className="text-sm text-muted-foreground font-medium flex-1 truncate">
                              {country}
                            </span>
                            <span className="text-xs text-green-400 font-bold shrink-0">
                              {count} ({pct}%)
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 }}
                className="glass-panel rounded-2xl p-6 border-border"
              >
                <div className="flex items-center gap-2 mb-5">
                  <CalendarDays className="w-5 h-5 text-cyan-400" />
                  <h3 className="font-bold text-foreground text-lg">
                    Recent Sign-ups
                  </h3>
                </div>
                {stats.recentSignups.length === 0 ? (
                  <p className="text-muted-foreground text-sm text-center py-4">
                    No sign-ups yet
                  </p>
                ) : (
                  <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1">
                    {stats.recentSignups.map((signup) => (
                      <div
                        key={signup.id}
                        className="flex items-center justify-between py-2.5 px-3 rounded-lg bg-background/40 border border-border"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              signup.status === "active"
                                ? "bg-green-500"
                                : signup.status === "pending"
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                          />
                          <div className="min-w-0">
                            <span className="text-sm text-foreground font-medium block truncate">
                              {signup.telegramId}
                            </span>
                            <span className="text-[10px] text-muted-foreground">
                              {signup.country}
                            </span>
                          </div>
                        </div>
                        <div className="text-right shrink-0 ml-2">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              signup.plan === "60-days"
                                ? "bg-primary/10 text-primary"
                                : "bg-blue-500/10 text-blue-400"
                            }`}
                          >
                            {signup.plan === "60-days" ? "60D" : "30D"}
                          </span>
                          <div className="text-[9px] text-muted-foreground mt-1">
                            {new Date(signup.createdAt).toLocaleDateString(
                              undefined,
                              { month: "short", day: "numeric" },
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            </div>
          </motion.div>
        )}

        {tab === "dashboard" && !stats && (
          <motion.div
            key="dashboard-loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-panel rounded-2xl p-16 text-center border-border"
          >
            <RefreshCw className="w-8 h-8 text-muted-foreground animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground font-light">Loading dashboard...</p>
          </motion.div>
        )}

        {(tab === "pending" || tab === "active") && (
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            transition={{ duration: 0.2 }}
          >
            {displayUsers.length === 0 ? (
              <div className="glass-panel rounded-2xl p-16 text-center border-border">
                <div className="w-16 h-16 mx-auto bg-card rounded-2xl flex items-center justify-center mb-4 border border-border">
                  {tab === "pending" ? (
                    <Clock className="w-7 h-7 text-muted-foreground" />
                  ) : (
                    <Users className="w-7 h-7 text-muted-foreground" />
                  )}
                </div>
                <p className="text-muted-foreground font-light">
                  {tab === "pending"
                    ? "No pending requests right now"
                    : "No active members yet"}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {displayUsers.map((user, i) => (
                  <motion.div
                    key={user.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="glass-panel rounded-2xl p-4 md:p-5 border-border hover:bg-card/30 transition-all"
                    data-testid={`member-card-${user.id}`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-center gap-4 flex-1 min-w-0">
                        {user.screenshotUrl ? (
                          <button
                            onClick={() => setPreviewImage(user.screenshotUrl!)}
                            className="w-12 h-12 md:w-14 md:h-14 rounded-xl overflow-hidden border border-border shrink-0 hover:border-primary/50 transition-colors group relative"
                            data-testid={`button-preview-${user.id}`}
                          >
                            <img
                              src={user.screenshotUrl}
                              alt="Payment proof"
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <Eye className="w-4 h-4 text-white" />
                            </div>
                          </button>
                        ) : (
                          <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl bg-card border border-border flex items-center justify-center shrink-0">
                            <ImageIcon className="w-5 h-5 text-muted-foreground" />
                          </div>
                        )}

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span
                              className="text-foreground font-bold text-sm truncate"
                              data-testid={`text-telegram-${user.id}`}
                            >
                              {user.telegramId}
                            </span>
                            <span className="text-muted-foreground text-xs">
                              #{user.id}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                user.plan === "60-days"
                                  ? "bg-primary/10 text-primary border border-primary/20"
                                  : "bg-blue-500/10 text-blue-400 border border-blue-500/20"
                              }`}
                            >
                              {user.plan === "60-days" ? "60 DAYS" : "30 DAYS"}
                            </span>
                            <span className="text-muted-foreground text-[10px]">
                              {user.paymentMethod}
                            </span>
                            <span className="text-muted-foreground text-[10px]">
                              {user.country}
                            </span>
                          </div>
                          <div className="text-[10px] text-muted-foreground mt-1">
                            {new Date(user.createdAt).toLocaleDateString()} at{" "}
                            {new Date(user.createdAt).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                            {user.expiryDate && (
                              <span className="ml-2 text-green-400">
                                Expires:{" "}
                                {new Date(user.expiryDate).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {tab === "pending" ? (
                          <>
                            <button
                              onClick={() => handleApprove(user.id)}
                              disabled={actionLoading === user.id}
                              className="smooth-button flex items-center gap-1.5 px-4 py-2 bg-green-500/10 text-green-500 border border-green-500/30 rounded-xl hover:bg-green-500 hover:text-black text-xs font-bold transition-all disabled:opacity-50"
                              data-testid={`button-approve-${user.id}`}
                            >
                              <Check className="w-3.5 h-3.5" />
                              Approve
                            </button>
                            <button
                              onClick={() => handleReject(user.id)}
                              disabled={actionLoading === user.id}
                              className="flex items-center gap-1.5 px-4 py-2 bg-red-500/10 text-red-500 border border-red-500/30 rounded-xl hover:bg-red-500 hover:text-white text-xs font-bold transition-all disabled:opacity-50"
                              data-testid={`button-reject-${user.id}`}
                            >
                              <X className="w-3.5 h-3.5" />
                              Reject
                            </button>
                          </>
                        ) : (
                          <div className="flex items-center gap-2">
                            {(user as any).blocked && (
                              <button
                                onClick={() => handleUnblock(user.id)}
                                disabled={actionLoading === user.id}
                                className="flex items-center gap-1.5 px-3 py-1.5 bg-yellow-500/10 text-yellow-500 border border-yellow-500/30 rounded-xl hover:bg-yellow-500 hover:text-black text-xs font-bold transition-all disabled:opacity-50"
                              >
                                Unblock
                              </button>
                            )}
                            <span className={`px-3 py-1.5 rounded-xl text-xs font-bold ${(user as any).blocked ? "bg-red-500/10 text-red-400 border border-red-500/20" : "bg-green-500/10 text-green-400 border border-green-500/20"}`}>
                              {(user as any).blocked ? "BLOCKED" : "ACTIVE"}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
