import { useState } from "react";
import { motion } from "framer-motion";
import { Play, Crown, Lock, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { demoVideos, type DemoVideo } from "@/lib/demoVideos";
import { useI18n } from "@/lib/i18n";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
};

function VideoCard({ video }: { video: DemoVideo }) {
  const { t } = useI18n();
  const [playing, setPlaying] = useState(false);
  const hasVideo = !!video.embedUrl;

  return (
    <motion.div
      variants={{ hidden: { opacity: 0, y: 24 }, visible: { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] } } }}
      className="rounded-2xl border border-border bg-card/50 backdrop-blur overflow-hidden group flex flex-col"
    >
      <div className="relative aspect-video bg-background flex items-center justify-center overflow-hidden">
        {hasVideo && playing ? (
          <iframe
            src={`${video.embedUrl}?autoplay=1`}
            className="w-full h-full"
            allow="autoplay; fullscreen"
            allowFullScreen
            title={video.title}
          />
        ) : (
          <>
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-primary/5" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div
                onClick={() => hasVideo && setPlaying(true)}
                className={`w-16 h-16 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                  hasVideo
                    ? "border-primary bg-primary/20 cursor-pointer group-hover:scale-110 group-hover:bg-primary/30 group-hover:shadow-[0_0_30px_rgba(var(--primary),0.4)]"
                    : "border-border bg-card/40 cursor-default opacity-40"
                }`}
              >
                {hasVideo ? (
                  <Play className="w-7 h-7 text-primary fill-primary ml-1" />
                ) : (
                  <Lock className="w-6 h-6 text-muted-foreground" />
                )}
              </div>
            </div>
            {!hasVideo && (
              <span className="absolute bottom-3 left-1/2 -translate-x-1/2 text-xs text-muted-foreground bg-background/80 px-3 py-1 rounded-full border border-border">
                {t("demos.comingSoon")}
              </span>
            )}
            <span className="absolute top-3 left-3 text-[10px] font-bold uppercase tracking-widest text-primary bg-primary/10 border border-primary/20 px-2.5 py-1 rounded-full">
              {video.tag}
            </span>
          </>
        )}
      </div>

      <div className="p-4 flex flex-col gap-2 flex-1">
        <h3 className="font-bold text-foreground text-base">{video.title}</h3>
        <p className="text-muted-foreground text-xs leading-relaxed flex-1">{video.desc}</p>
        <Link
          href="/checkout/30-days"
          className="mt-2 text-center text-xs font-bold text-primary border border-primary/30 bg-primary/5 hover:bg-primary/15 py-2 rounded-xl transition-colors"
        >
          {t("demos.getVipAccess")}
        </Link>
      </div>
    </motion.div>
  );
}

export default function Demos() {
  const { t } = useI18n();
  const [activeTag, setActiveTag] = useState("all");

  const VIDEO_TAGS = Array.from(new Set(demoVideos.map((v) => v.tag)));
  const TAGS = [{ key: "all", label: t("demos.filterAll") }, ...VIDEO_TAGS.map((tag) => ({ key: tag, label: tag }))];

  const filtered = activeTag === "all" ? demoVideos : demoVideos.filter((v) => v.tag === activeTag);

  return (
    <div className="min-h-screen bg-background pt-28 pb-16 px-4">
      <div className="container mx-auto max-w-5xl">
        <motion.div {...fadeUp} className="mb-6">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm font-medium transition-colors group"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            {t("demos.backHome")}
          </Link>
        </motion.div>

        <motion.div {...fadeUp} className="text-center mb-10">
          <span className="inline-flex items-center gap-2 text-primary text-xs font-bold uppercase tracking-widest mb-3 bg-primary/10 border border-primary/20 px-4 py-1.5 rounded-full">
            <Play className="w-3.5 h-3.5" /> {t("demos.badge")}
          </span>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mt-3 mb-3">
            {t("demos.title")}{" "}
            <span className="text-primary">{t("demos.titleHighlight")}</span>
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto text-sm leading-relaxed">
            {t("demos.subtitle")}
          </p>
        </motion.div>

        <motion.div {...fadeUp} className="flex flex-wrap gap-2 justify-center mb-8">
          {TAGS.map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setActiveTag(key)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                activeTag === key
                  ? "bg-primary text-primary-foreground border-primary shadow-[0_0_12px_rgba(var(--primary),0.3)]"
                  : "bg-card border-border text-muted-foreground hover:border-primary/40 hover:text-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </motion.div>

        <motion.div
          key={activeTag}
          variants={{ hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.08 } } }}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          {filtered.map((video) => (
            <VideoCard key={video.id} video={video} />
          ))}
        </motion.div>

        <motion.div {...fadeUp} className="mt-14 text-center">
          <div className="inline-block bg-card/60 border border-border rounded-2xl px-8 py-6 max-w-md">
            <Crown className="w-8 h-8 text-primary mx-auto mb-3" />
            <h2 className="font-bold text-foreground text-lg mb-2">{t("demos.ctaTitle")}</h2>
            <p className="text-muted-foreground text-sm mb-4">{t("demos.ctaDesc")}</p>
            <Link
              href="/checkout/30-days"
              className="inline-flex items-center gap-2 bg-yellow-400 hover:bg-yellow-300 text-gray-900 font-bold px-8 py-3 rounded-xl text-sm transition-colors shadow-[0_0_16px_rgba(234,179,8,0.4)]"
            >
              <Crown className="w-4 h-4" /> {t("demos.ctaButton")}
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
