import { motion } from "framer-motion";
import { Link } from "wouter";
import { Shield, ArrowLeft } from "lucide-react";

const fadeUp = { initial: { opacity: 0, y: 20 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true } };

export default function Terms() {
  return (
    <div className="min-h-screen pt-24 pb-10 px-6">
      <div className="container mx-auto max-w-3xl">
        <motion.div {...fadeUp}>
          <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm mb-8" data-testid="link-back-home">
            <ArrowLeft className="w-4 h-4" /> Back to Home
          </Link>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center border border-primary/20">
              <Shield className="w-7 h-7 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground font-heading" data-testid="text-terms-title">Terms of Service</h1>
              <p className="text-muted-foreground text-sm mt-1">Last updated: February 2026</p>
            </div>
          </div>
        </motion.div>

        <motion.div {...fadeUp} transition={{ delay: 0.1 }} className="glass-panel rounded-2xl p-8 md:p-10 space-y-8">
          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">1. Acceptance of Terms</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">By accessing and using ZakPubgSkin services, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services. These terms apply to all visitors, users, and members of the platform.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">2. Membership Plans</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">ZakPubgSkin offers VIP membership plans (30-day and 60-day). Upon successful payment verification, your membership will be activated for the selected duration. Memberships are non-transferable and are tied to a single Telegram account.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">3. Payment & Verification</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">All payments must be made through the supported payment methods listed on our checkout page. A valid payment screenshot must be provided for verification. Our team reviews each payment manually and reserves the right to approve or reject any payment submission. Approval typically takes 5-15 minutes.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">4. Refund Policy</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">Due to the digital nature of our products, all sales are final. Refunds are not available once a membership has been activated. If your payment was rejected, you may resubmit with correct payment details. For disputes, please contact our support team.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">5. User Conduct</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">Users agree not to share, redistribute, or resell any files, configs, or content provided through the VIP membership. Sharing account credentials or VIP content with non-members will result in immediate membership termination without refund.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">6. Service Availability</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">We strive to provide uninterrupted service but do not guarantee 100% uptime. Configs and files are updated regularly to maintain performance. We reserve the right to modify, update, or discontinue services at any time.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">7. Limitation of Liability</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">ZakPubgSkin is not responsible for any account bans, game restrictions, or other consequences resulting from the use of our products. Users assume all risks associated with using third-party configurations in games.</p>
          </section>

          <section>
            <h2 className="text-xl font-bold text-foreground mb-3">8. Changes to Terms</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">We reserve the right to update these terms at any time. Continued use of our services after changes constitutes acceptance of the new terms. Users will be notified of significant changes through our Telegram channel.</p>
          </section>

          <div className="pt-4 border-t border-border">
            <p className="text-muted-foreground text-xs">For questions about these terms, contact us on <a href="https://t.me/Zaksite_bot" target="_blank" className="text-primary hover:underline">Telegram</a>.</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
