import { useState, useEffect, useRef } from "react";
import { useLocation, useParams } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Upload,
  Copy,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  ShieldCheck,
  CreditCard,
  User,
  Image as ImageIcon,
  MapPin,
  AlertTriangle,
  X,
  Crown,
  Gift,
} from "lucide-react";
import { useStore } from "@/lib/store";
import { submitPayment } from "@/lib/api";
import { useI18n } from "@/lib/i18n";
import { PaymentIcon } from "@/components/PaymentIcons";

interface CountryConfig {
  flag: string;
  currency: string;
  symbol: string;
  price30: number;
  price60: number;
  methods: {
    id: string;
    name: string;
    icon: string;
    details: { accountName: string; accountNumber: string; iban?: string; ifsc?: string; instructions?: string };
  }[];
}

const countryData: Record<string, CountryConfig> = {
  Global: {
    flag: "🌍",
    currency: "USD",
    symbol: "$",
    price30: 14.99,
    price60: 24.99,
    methods: [
      {
        id: "paypal",
        name: "PayPal",
        icon: "💰",
        details: {
          accountName: "PayPal",
          accountNumber: "Nirmalr7565@gmail.com",
        },
      },
      {
        id: "binance",
        name: "Binance Pay",
        icon: "₿",
        details: {
          accountName: "MZAKARYA",
          accountNumber: "919258288 (Pay ID)",
        },
      },
      {
        id: "binancegift",
        name: "Binance Gift Card",
        icon: "🎁",
        details: {
          accountName: "🎁 Binance Gift Card Payment",
          accountNumber: "",
          instructions: "Buy a Binance Gift Card for the exact amount shown above\nCopy the redeem code from your gift card\nPaste the redeem code in the field below\nUpload a screenshot of the gift card as proof",
        },
      },
      {
        id: "usdt-trc20",
        name: "USDT TRC20",
        icon: "💎",
        details: {
          accountName: "USDT (TRC20 Network)",
          accountNumber: "TUebrdMXzYGaxKubGp9J95z5TJuwtZnfvG",
        },
      },
      {
        id: "usdt-bep20",
        name: "USDT BEP20",
        icon: "💎",
        details: {
          accountName: "USDT (BEP20 Network)",
          accountNumber: "0x372c783712d1eE660997D3Fb022d8E6D9085587D",
        },
      },
      {
        id: "trx",
        name: "TRX",
        icon: "💎",
        details: {
          accountName: "TRX (Tron)",
          accountNumber: "TUebrdMXzYGaxKubGp9J95z5TJuwtZnfvG",
        },
      },
      {
        id: "ton",
        name: "TON",
        icon: "💎",
        details: {
          accountName: "TON (Toncoin)",
          accountNumber: "UQAhw1Opij5jk3MGOdiFnx36IaVF_T8vAh3QkI53RZhSULEW",
        },
      },
      {
        id: "bankintl",
        name: "Bank International",
        icon: "🏦",
        details: {
          accountName: "MUHAMMAD ZEKARYA",
          accountNumber: "10260113072049",
          iban: "PK58MEZN0010260113072049",
        },
      },
      {
        id: "tgpremium",
        name: "Telegram Premium",
        icon: "✈️",
        details: {
          accountName: "Gift Telegram Premium to",
          accountNumber: "@Zakarya_OP",
        },
      },
    ],
  },
  Pakistan: {
    flag: "🇵🇰",
    currency: "PKR",
    symbol: "Rs",
    price30: 2999,
    price60: 4999,
    methods: [
      {
        id: "easypaisa",
        name: "Easypaisa",
        icon: "📱",
        details: {
          accountName: "Muhammad zakarya",
          accountNumber: "03292193373",
        },
      },
      {
        id: "jazzcash",
        name: "JazzCash",
        icon: "📱",
        details: {
          accountName: "Muhammad zakarya",
          accountNumber: "03292193373",
        },
      },
      {
        id: "nayapay",
        name: "NayaPay",
        icon: "📱",
        details: {
          accountName: "Muhammad zakarya",
          accountNumber: "zakaryaop@nayapay",
        },
      },
      {
        id: "bank",
        name: "Meezan Bank",
        icon: "🏦",
        details: {
          accountName: "MUHAMMAD ZEKARYA",
          accountNumber: "10260113072049",
          iban: "PK58MEZN0010260113072049",
        },
      },
    ],
  },
  India: {
    flag: "🇮🇳",
    currency: "INR",
    symbol: "₹",
    price30: 999,
    price60: 1499,
    methods: [
      {
        id: "upi",
        name: "UPI",
        icon: "📱",
        details: {
          accountName: "Mohd Ovais",
          accountNumber: "mohdobais@ptaxis",
        },
      },
      {
        id: "bank",
        name: "FINO Bank",
        icon: "🏦",
        details: {
          accountName: "Mohd Ovais",
          accountNumber: "20405151677",
          ifsc: "FINO0009001",
        },
      },
    ],
  },
  Bangladesh: {
    flag: "🇧🇩",
    currency: "BDT",
    symbol: "৳",
    price30: 1299,
    price60: 1999,
    methods: [
      {
        id: "bkash",
        name: "bKash Personal",
        icon: "📱",
        details: {
          accountName: "Shahariar Hosen",
          accountNumber: "01875439986",
        },
      },
      {
        id: "nagad",
        name: "Nagad Personal",
        icon: "📱",
        details: {
          accountName: "Shahariar Hosen",
          accountNumber: "01875439986",
        },
      },
    ],
  },
  Nepal: {
    flag: "🇳🇵",
    currency: "NPR",
    symbol: "रू",
    price30: 1499,
    price60: 2299,
    methods: [
      {
        id: "esewa",
        name: "eSewa",
        icon: "📱",
        details: {
          accountName: "Askam Nadaf",
          accountNumber: "9817830705",
        },
      },
      {
        id: "khalti",
        name: "Khalti",
        icon: "📱",
        details: {
          accountName: "Aslam Nadaf",
          accountNumber: "9817830705",
        },
      },
    ],
  },
  Iran: {
    flag: "🇮🇷",
    currency: "IRR",
    symbol: "﷼",
    price30: 800000,
    price60: 1499999,
    methods: [
      {
        id: "cardtocard",
        name: "Card to Card",
        icon: "💳",
        details: {
          accountName: "ارسلان عزیززاده",
          accountNumber: "6219861815503247",
        },
      },
    ],
  },
  Turkey: {
    flag: "🇹🇷",
    currency: "TRY",
    symbol: "₺",
    price30: 449,
    price60: 849,
    methods: [
      {
        id: "cardtocard",
        name: "Visa Card",
        icon: "💳",
        details: {
          accountName: "ERDEM ERTAN",
          accountNumber: "5276820329918012",
        },
      },
    ],
  },
};

const countryNames = Object.keys(countryData);

function formatPrice(value: number, currency: string): string {
  if (currency === "IRR") {
    return (value / 1000).toLocaleString() + "k";
  }
  return value.toLocaleString();
}

export default function Checkout() {
  const { t } = useI18n();
  const { plan } = useParams<{ plan: string }>();
  const [, setLocation] = useLocation();
  const [step, setStep] = useState(1);
  useEffect(() => { window.scrollTo({ top: 0, behavior: "smooth" }); }, [step]);
  const [telegramId, setTelegramId] = useState(() => sessionStorage.getItem("vip_pending_id") || "");
  const [country, setCountry] = useState("Global");
  const [countryOpen, setCountryOpen] = useState(false);
  const [method, setMethod] = useState("");
  const [copied, setCopied] = useState(false);
  const [screenshot, setScreenshot] = useState<File | null>(null);
  const [giftCardCode, setGiftCardCode] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(() => !!sessionStorage.getItem("vip_pending_id"));
  const [error, setError] = useState("");
  const [showAlreadyActive, setShowAlreadyActive] = useState(false);
  const [showPendingPopup, setShowPendingPopup] = useState(false);
  const [refCode] = useState(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get("ref") || "";
  });

  const config = countryData[country];
  const rawPrice = plan === "60-days" ? config.price60 : config.price30;
  const priceDisplay = `${config.symbol}${formatPrice(rawPrice, config.currency)}`;
  const planName = plan === "60-days" ? "VIP 60 Days" : "VIP 30 Days";

  const selectedMethods = config.methods;
  const selectedMethodDetails = selectedMethods.find(
    (m) => m.id === method,
  )?.details;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSelectCountry = (c: string) => {
    setCountry(c);
    setMethod("");
    setCountryOpen(false);
  };

  const isBinanceGiftCard = method === "binancegift";

  const handleSubmit = async () => {
    if (!telegramId || !method || !screenshot) return;
    if (isBinanceGiftCard && !giftCardCode.trim()) return;

    setIsSubmitting(true);
    setError("");

    try {
      await submitPayment({
        telegramId,
        plan: plan || "30-days",
        country,
        paymentMethod:
          selectedMethods.find((m) => m.id === method)?.name || method,
        screenshot,
        giftCardCode: isBinanceGiftCard ? giftCardCode.trim() : undefined,
        referralCode: refCode || undefined,
      });

      sessionStorage.setItem("vip_pending_id", telegramId);
      setSubmitted(true);
    } catch (err: any) {
      const msg = err.message || "";
      if (msg.toLowerCase().includes("already have an active")) {
        setShowAlreadyActive(true);
      } else if (msg.toLowerCase().includes("pending")) {
        setShowPendingPopup(true);
      } else {
        setError(msg || "Something went wrong. Please try again.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const [orderStatus, setOrderStatus] = useState<"pending"|"active"|"rejected">("pending");
  const [inviteLink, setInviteLink] = useState<string|null>(null);
  const [dots, setDots] = useState(".");
  const intervalRef = useRef<ReturnType<typeof setInterval>|null>(null);
  const dotsRef = useRef<ReturnType<typeof setInterval>|null>(null);

  useEffect(() => {
    if (!submitted) return;

    const poll = async () => {
      try {
        const res = await fetch(`/api/order-status?telegramId=${encodeURIComponent(telegramId)}`);
        const data = await res.json();
        setOrderStatus(data.status);
        if (data.inviteLink) setInviteLink(data.inviteLink);
        if (data.status === "active" && data.inviteLink) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          sessionStorage.removeItem("vip_pending_id");
        }
        if (data.status === "rejected") {
          if (intervalRef.current) clearInterval(intervalRef.current);
          sessionStorage.removeItem("vip_pending_id");
        }
      } catch {}
    };

    poll();
    intervalRef.current = setInterval(poll, 5000);
    dotsRef.current = setInterval(() => setDots(d => d.length >= 3 ? "." : d + "."), 600);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (dotsRef.current) clearInterval(dotsRef.current);
    };
  }, [submitted, telegramId]);

  if (submitted) {
    const isApproved = orderStatus === "active" && inviteLink;
    const isRejected = orderStatus === "rejected";

    return (
      <div className="min-h-screen flex items-center justify-center pt-20 pb-12 px-6 relative overflow-hidden">
        <AnimatePresence mode="wait">
          {isApproved ? (
            <motion.div
              key="approved"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass-panel p-10 md:p-12 rounded-[2rem] max-w-lg w-full text-center border-primary/30"
            >
              <div className="w-24 h-24 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-6 shadow-[0_0_40px_rgba(var(--primary),0.3)]">
                <Crown className="w-12 h-12 text-primary" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2" data-testid="text-payment-success">
                You're In! 🎉
              </h2>
              <p className="text-muted-foreground mb-6 text-sm">
                Your VIP is active. Tap the button below to join your exclusive group.
              </p>
              <a
                href={inviteLink}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full smooth-button bg-primary text-primary-foreground font-bold py-4 rounded-2xl text-base mb-3 shadow-[0_0_30px_rgba(var(--primary),0.4)]"
              >
                🚀 Join VIP Group Now
              </a>
              <p className="text-muted-foreground text-xs">This link is yours only — valid 24h, single use</p>
            </motion.div>
          ) : isRejected ? (
            <motion.div
              key="rejected"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass-panel p-10 md:p-12 rounded-[2rem] max-w-lg w-full text-center border-red-500/20"
            >
              <div className="w-20 h-20 mx-auto rounded-full bg-red-500/10 flex items-center justify-center mb-6">
                <X className="w-10 h-10 text-red-400" />
              </div>
              <h2 className="text-2xl font-bold text-foreground mb-2">Payment Not Verified</h2>
              <p className="text-muted-foreground mb-6 text-sm">
                Your screenshot could not be verified. Please contact support for help.
              </p>
              <div className="flex gap-3">
                <a href="https://t.me/zakarya_op" target="_blank" rel="noopener noreferrer"
                  className="flex-1 bg-primary text-primary-foreground font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L7.41 13.946l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.738.613z"/></svg>
                  Contact Support
                </a>
                <a href="https://wa.me/923192530306" target="_blank" rel="noopener noreferrer"
                  className="flex-1 bg-green-600 text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2">
                  WhatsApp
                </a>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="pending"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass-panel p-10 md:p-12 rounded-[2rem] max-w-lg w-full text-center border-primary/20"
            >
              <div className="w-20 h-20 mx-auto mb-6 relative">
                <svg className="animate-spin w-20 h-20 text-primary/30" viewBox="0 0 100 100" fill="none">
                  <circle cx="50" cy="50" r="44" stroke="currentColor" strokeWidth="8"/>
                </svg>
                <svg className="animate-spin w-20 h-20 text-primary absolute inset-0" style={{animationDuration:"1.2s"}} viewBox="0 0 100 100" fill="none">
                  <circle cx="50" cy="50" r="44" stroke="currentColor" strokeWidth="8" strokeDasharray="80 200" strokeLinecap="round"/>
                </svg>
                <CheckCircle2 className="w-8 h-8 text-primary absolute inset-0 m-auto" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2" data-testid="text-payment-success">
                Payment Submitted! ✅
              </h2>
              <p className="text-muted-foreground mb-6 font-light text-sm">
                Reviewing your payment{dots} Keep this page open — your VIP invite link will appear here automatically once approved.
              </p>
              <div className="bg-primary/10 border border-primary/20 rounded-xl px-5 py-3 mb-6">
                <p className="text-primary font-bold text-sm">🔄 Checking status every 5 seconds</p>
                <p className="text-muted-foreground text-xs mt-0.5">No need to refresh — this page updates automatically</p>
              </div>
              <div className="flex gap-3">
                <a href="https://t.me/zakarya_op" target="_blank" rel="noopener noreferrer"
                  className="smooth-button flex-1 bg-card border border-border text-foreground font-semibold py-2.5 rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-card/80 transition-colors">
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L7.41 13.946l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.738.613z"/></svg>
                  Support
                </a>
                <a href="https://wa.me/923192530306" target="_blank" rel="noopener noreferrer"
                  className="smooth-button flex-1 bg-card border border-border text-foreground font-semibold py-2.5 rounded-xl text-sm flex items-center justify-center gap-2 hover:bg-card/80 transition-colors">
                  WhatsApp
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 pb-6 px-4 bg-background relative">
      <div className="container mx-auto max-w-xl">
        {refCode && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-4 flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-xl px-4 py-2.5 text-sm"
            data-testid="badge-referral"
          >
            <Gift className="w-4 h-4 text-primary" />
            <span className="text-foreground font-medium">{t("checkout.referredBy")}: <span className="text-primary font-bold">{refCode}</span></span>
          </motion.div>
        )}
        <div className="mb-6">
          <div className="flex justify-between items-center relative">
            <div className="absolute left-0 top-1/2 w-full h-[2px] bg-card/30 -z-10"></div>
            <div
              className="absolute left-0 top-1/2 h-[2px] bg-primary transition-all duration-500 -z-10"
              style={{ width: `${((step - 1) / 2) * 100}%` }}
            ></div>

            {[
              { num: 1, icon: User, label: "Account" },
              { num: 2, icon: CreditCard, label: "Payment" },
              { num: 3, icon: ImageIcon, label: "Verify" },
            ].map((s) => (
              <div
                key={s.num}
                className="flex flex-col items-center gap-2 md:gap-3"
              >
                <div
                  className={`w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center border-2 transition-all duration-500 ${
                    step >= s.num
                      ? "bg-primary border-primary text-primary-foreground shadow-[0_0_15px_rgba(var(--primary),0.3)]"
                      : "bg-card border-border text-muted-foreground"
                  }`}
                >
                  <s.icon className="w-4 h-4 md:w-5 md:h-5" />
                </div>
                <span
                  className={`text-xs md:text-sm font-bold ${step >= s.num ? "text-foreground" : "text-muted-foreground"}`}
                >
                  {s.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-panel rounded-2xl p-4 md:p-6 border-border shadow-2xl relative overflow-hidden bg-card/40">
          <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/5 blur-[100px] rounded-full pointer-events-none"></div>

          <div className="flex justify-between items-center mb-4 pb-4 border-b border-border">
            <div>
              <h1
                className="text-xl md:text-2xl font-bold text-foreground mb-1"
                data-testid="text-checkout-title"
              >
                {t("checkout.title")}
              </h1>
              <p className="text-muted-foreground font-light text-sm">
                {t("checkout.purchasing")} {planName}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] md:text-xs text-muted-foreground uppercase tracking-widest font-medium mb-1">
                {t("checkout.total")}
              </p>
              <motion.p
                key={priceDisplay}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="text-2xl md:text-3xl font-extrabold text-primary"
                data-testid="text-price"
              >
                {priceDisplay}
              </motion.p>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                {config.currency}
              </p>
            </div>
          </div>

          {error && (
            <div className="mb-6 bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-red-400 text-sm">
              {error}
            </div>
          )}

          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-4"
              >
                <div>
                  <h2 className="text-lg md:text-xl font-bold text-foreground mb-3">
                    {t("checkout.step1.title")}
                  </h2>
                  <p className="text-muted-foreground mb-5 font-light text-sm md:text-base">
                    {t("checkout.step1.desc")}
                  </p>

                  <div className="relative group mb-4">
                    <span className="absolute left-4 top-3.5 text-muted-foreground font-medium">
                      @
                    </span>
                    <input
                      type="text"
                      autoFocus
                      value={telegramId.replace("@", "")}
                      onChange={(e) => setTelegramId("@" + e.target.value)}
                      placeholder="Telegram username"
                      className="w-full bg-card/70 border border-border rounded-xl py-3 pl-10 pr-5 text-foreground text-base focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-muted-foreground"
                      data-testid="input-telegram-id"
                    />
                  </div>

                  <p className="text-xs text-muted-foreground mt-2">
                    💬 After payment is verified, your VIP access will be sent to you on Telegram.
                  </p>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={() => setStep(2)}
                    disabled={!telegramId || telegramId === "@"}
                    className="smooth-button bg-white text-black px-6 py-3 rounded-xl font-bold flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-200 text-sm"
                    data-testid="button-continue-step2"
                  >
                    {t("checkout.step1.continue")}{" "}
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-4"
              >
                <div>
                  <h2 className="text-lg font-bold text-foreground mb-3">
                    {t("checkout.step2.title")}
                  </h2>

                  <div className="mb-3">
                    <label className="block text-sm font-medium text-muted-foreground mb-3">
                      {t("checkout.step2.region")}
                    </label>
                    <div className="relative">
                      <button
                        onClick={() => setCountryOpen(!countryOpen)}
                        className="w-full bg-card/70 border border-border rounded-xl py-3.5 px-4 text-left text-foreground focus:border-primary outline-none cursor-pointer text-sm flex items-center justify-between hover:border-border transition-all"
                        data-testid="button-country-selector"
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-xl">{config.flag}</span>
                          <div>
                            <span className="font-medium">{country}</span>
                            <span className="text-muted-foreground ml-2 text-xs">
                              ({config.currency})
                            </span>
                          </div>
                        </div>
                        <ChevronRight
                          className={`w-4 h-4 text-muted-foreground transition-transform duration-200 ${countryOpen ? "rotate-90" : ""}`}
                        />
                      </button>

                      <AnimatePresence>
                        {countryOpen && (
                          <>
                            <div
                              className="fixed inset-0 z-40"
                              onClick={() => setCountryOpen(false)}
                            />
                            <motion.div
                              initial={{ opacity: 0, y: -5, scale: 0.98 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, y: -5, scale: 0.98 }}
                              transition={{ duration: 0.15 }}
                              className="absolute top-full left-0 right-0 mt-2 bg-card/95 backdrop-blur-2xl border border-border rounded-2xl shadow-2xl z-50 overflow-hidden max-h-[320px] overflow-y-auto"
                            >
                              {countryNames.map((c) => {
                                const cd = countryData[c];
                                const localPrice =
                                  plan === "60-days" ? cd.price60 : cd.price30;
                                return (
                                  <button
                                    key={c}
                                    onClick={() => handleSelectCountry(c)}
                                    className={`w-full flex items-center justify-between px-4 py-3.5 text-left transition-all ${
                                      country === c
                                        ? "bg-primary/10 text-primary"
                                        : "text-foreground hover:bg-card/30"
                                    }`}
                                    data-testid={`country-option-${c}`}
                                  >
                                    <div className="flex items-center gap-3">
                                      <span className="text-xl w-8 text-center">
                                        {cd.flag}
                                      </span>
                                      <div>
                                        <span className="font-medium text-sm">
                                          {c}
                                        </span>
                                        <span className="text-muted-foreground ml-2 text-[10px] uppercase">
                                          {cd.currency}
                                        </span>
                                      </div>
                                    </div>
                                    <span
                                      className={`text-xs font-bold ${country === c ? "text-primary" : "text-muted-foreground"}`}
                                    >
                                      {cd.symbol}
                                      {formatPrice(localPrice, cd.currency)}
                                    </span>
                                  </button>
                                );
                              })}
                            </motion.div>
                          </>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {selectedMethods.map((m) => (
                      <button
                        key={m.id}
                        onClick={() => setMethod(m.id)}
                        className={`p-2.5 rounded-xl border-2 text-center transition-all relative overflow-hidden flex flex-col items-center justify-center gap-1.5 ${
                          method === m.id
                            ? "bg-primary/10 border-primary"
                            : "bg-card/30 border-border hover:border-border hover:bg-card/40"
                        }`}
                        data-testid={`method-${m.id}`}
                      >
                        {method === m.id && (
                          <div className="absolute top-1.5 right-1.5 text-primary">
                            <CheckCircle2 className="w-3.5 h-3.5 fill-primary text-primary-foreground" />
                          </div>
                        )}
                        <PaymentIcon methodId={m.id} className="w-6 h-6" />
                        <span
                          className={`block font-semibold text-xs ${method === m.id ? "text-primary" : "text-foreground"}`}
                        >
                          {m.name}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2">
                  <button
                    onClick={() => setStep(1)}
                    className="text-muted-foreground hover:text-foreground flex items-center gap-1 font-medium transition-colors text-sm"
                    data-testid="button-back-step1"
                  >
                    <ChevronLeft className="w-4 h-4" />{" "}
                    {t("checkout.step2.back")}
                  </button>
                  <button
                    onClick={() => setStep(3)}
                    disabled={!method}
                    className="smooth-button bg-white text-black px-6 py-3 rounded-xl font-bold flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-200 text-sm"
                    data-testid="button-continue-step3"
                  >
                    {t("checkout.step2.showDetails")}{" "}
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            )}

            {step === 3 && selectedMethodDetails && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-4"
              >
                <div>
                  <h2 className="text-lg md:text-xl font-bold text-foreground mb-2">
                    {t("checkout.step3.title")}
                  </h2>
                  <p className="text-muted-foreground mb-3 font-light text-sm">
                    {t("checkout.step3.sendExactly")}{" "}
                    <strong className="text-foreground font-medium">
                      {priceDisplay} {config.currency}
                    </strong>{" "}
                    {t("checkout.step3.via")}{" "}
                    <span className="text-primary font-medium">
                      {selectedMethods.find((m) => m.id === method)?.name}
                    </span>
                    .
                  </p>

                  <div className="mb-3 bg-gradient-to-br from-white/5 to-transparent p-5 rounded-2xl border border-border relative overflow-hidden shadow-inner group hover:border-primary/30 transition-all duration-500">
                    <div className="absolute -right-10 -bottom-10 opacity-[0.03] group-hover:opacity-10 transition-opacity duration-500">
                      <CreditCard className="w-40 h-40" />
                    </div>

                    <div className="flex items-center gap-2 mb-4 relative z-10">
                      <span className="text-lg">{config.flag}</span>
                      <span className="text-xs text-muted-foreground font-medium">
                        {country} &middot; {config.currency}
                      </span>
                      <span className="ml-auto text-primary font-bold text-lg">
                        {priceDisplay}
                      </span>
                    </div>

                    <div className="relative z-10">
                      <p className="text-[10px] text-primary uppercase tracking-widest font-bold mb-1">
                        {t("checkout.step3.accountName")}
                      </p>
                      <p className="text-lg md:text-xl text-foreground font-bold tracking-wide">
                        {selectedMethodDetails.accountName}
                      </p>
                    </div>
                    {selectedMethodDetails.accountNumber ? (
                      <div className="relative z-10 pt-4 mt-4 border-t border-border">
                        <p className="text-[10px] text-primary uppercase tracking-widest font-bold mb-2">
                          {t("checkout.step3.accountNumber")}
                        </p>
                        <div className="flex items-center justify-between bg-card/70 rounded-xl p-2.5 pl-4 border border-border shadow-inner">
                          <span className="text-foreground font-mono text-base md:text-lg tracking-wider truncate pr-4">
                            {selectedMethodDetails.accountNumber}
                          </span>
                          <button
                            onClick={() =>
                              handleCopy(selectedMethodDetails.accountNumber)
                            }
                            className="shrink-0 bg-primary/10 hover:bg-primary/20 text-primary p-2.5 rounded-lg transition-colors flex items-center justify-center border border-primary/20 group/btn"
                            title="Copy to clipboard"
                            data-testid="button-copy"
                          >
                            {copied ? (
                              <CheckCircle2 className="w-4 h-4" />
                            ) : (
                              <Copy className="w-4 h-4 group-hover/btn:scale-110 transition-transform" />
                            )}
                          </button>
                        </div>
                      </div>
                    ) : selectedMethodDetails.instructions ? (
                      <div className="relative z-10 pt-4 mt-4 border-t border-border">
                        <p className="text-[10px] text-primary uppercase tracking-widest font-bold mb-2">
                          📋 HOW TO PAY
                        </p>
                        <div className="bg-card/70 rounded-xl p-4 border border-border text-sm text-muted-foreground space-y-1.5">
                          {selectedMethodDetails.instructions.split("\n").map((line, i) => (
                            <p key={i} className="flex items-start gap-2">
                              <span className="text-primary font-bold shrink-0">{i + 1}.</span>
                              <span>{line.replace(/^\d+\.\s*/, "")}</span>
                            </p>
                          ))}
                        </div>
                      </div>
                    ) : null}
                    {selectedMethodDetails.iban && (
                      <div className="relative z-10 pt-4 mt-4 border-t border-border">
                        <p className="text-[10px] text-primary uppercase tracking-widest font-bold mb-2">
                          IBAN
                        </p>
                        <div className="flex items-center justify-between bg-card/70 rounded-xl p-2.5 pl-4 border border-border shadow-inner">
                          <span className="text-foreground font-mono text-sm md:text-base tracking-wider truncate pr-4">
                            {selectedMethodDetails.iban}
                          </span>
                          <button
                            onClick={() =>
                              handleCopy(selectedMethodDetails.iban!)
                            }
                            className="shrink-0 bg-primary/10 hover:bg-primary/20 text-primary p-2.5 rounded-lg transition-colors flex items-center justify-center border border-primary/20 group/btn"
                            title="Copy IBAN"
                          >
                            <Copy className="w-4 h-4 group-hover/btn:scale-110 transition-transform" />
                          </button>
                        </div>
                      </div>
                    )}
                    {selectedMethodDetails.ifsc && (
                      <div className="relative z-10 pt-4 mt-4 border-t border-border">
                        <p className="text-[10px] text-primary uppercase tracking-widest font-bold mb-2">
                          IFSC CODE
                        </p>
                        <div className="flex items-center justify-between bg-card/70 rounded-xl p-2.5 pl-4 border border-border shadow-inner">
                          <span className="text-foreground font-mono text-base md:text-lg tracking-wider truncate pr-4">
                            {selectedMethodDetails.ifsc}
                          </span>
                          <button
                            onClick={() =>
                              handleCopy(selectedMethodDetails.ifsc!)
                            }
                            className="shrink-0 bg-primary/10 hover:bg-primary/20 text-primary p-2.5 rounded-lg transition-colors flex items-center justify-center border border-primary/20 group/btn"
                            title="Copy IFSC"
                          >
                            <Copy className="w-4 h-4 group-hover/btn:scale-110 transition-transform" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {isBinanceGiftCard && (
                    <div>
                      <h3 className="font-bold text-foreground mb-3 text-sm md:text-base flex items-center gap-2">
                        <Gift className="w-4 h-4 text-primary" />
                        Gift Card Redeem Code
                      </h3>
                      <div className="relative group">
                        <input
                          type="text"
                          value={giftCardCode}
                          onChange={(e) => setGiftCardCode(e.target.value)}
                          placeholder="Enter your Binance gift card redeem code"
                          className="w-full bg-card/70 border border-border rounded-xl py-3 px-4 text-foreground text-base focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-muted-foreground font-mono tracking-wider"
                          data-testid="input-gift-card-code"
                        />
                      </div>
                      {giftCardCode.trim() === "" && (
                        <p className="text-xs text-yellow-500 mt-2 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          Gift card code is required for this payment method
                        </p>
                      )}
                    </div>
                  )}

                  <div>
                    <h3 className="font-bold text-foreground mb-3 text-sm md:text-base">
                      {t("checkout.step3.uploadTitle")}
                    </h3>
                    <div
                      className={`border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer ${
                        screenshot
                          ? "border-primary bg-primary/5"
                          : "border-border bg-card/30 hover:border-primary/30 hover:bg-card/40"
                      }`}
                      onClick={() =>
                        document.getElementById("screenshot-upload")?.click()
                      }
                    >
                      <input
                        type="file"
                        id="screenshot-upload"
                        className="hidden"
                        accept="image/*"
                        onChange={(e) =>
                          setScreenshot(e.target.files?.[0] || null)
                        }
                      />
                      {screenshot ? (
                        <div className="flex flex-col items-center">
                          <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center mb-2">
                            <CheckCircle2 className="w-5 h-5 text-primary" />
                          </div>
                          <span className="text-foreground font-bold text-sm">
                            {screenshot.name}
                          </span>
                          <span className="text-xs text-primary mt-1">
                            {t("checkout.step3.uploadReplace")}
                          </span>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                          <div className="w-10 h-10 bg-card/30 rounded-full flex items-center justify-center mb-2 text-muted-foreground">
                            <Upload className="w-5 h-5" />
                          </div>
                          <span className="text-foreground font-bold mb-1 text-sm">
                            {t("checkout.step3.uploadClick")}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {t("checkout.step3.uploadFormats")}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2 border-t border-border">
                  <button
                    onClick={() => setStep(2)}
                    className="text-muted-foreground hover:text-foreground flex items-center gap-1 font-medium transition-colors text-sm"
                    data-testid="button-back-step2"
                  >
                    <ChevronLeft className="w-4 h-4" />{" "}
                    {t("checkout.step2.back")}
                  </button>
                  <button
                    onClick={handleSubmit}
                    disabled={!screenshot || isSubmitting || (isBinanceGiftCard && !giftCardCode.trim())}
                    className="smooth-button bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                    data-testid="button-submit"
                  >
                    {isSubmitting
                      ? t("checkout.step3.processing")
                      : t("checkout.step3.submit")}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="mt-8 pt-6 flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="w-4 h-4 text-primary" />
            <span>{t("checkout.secure")}</span>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showAlreadyActive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/70 backdrop-blur-sm"
            onClick={() => setShowAlreadyActive(false)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.85, opacity: 0, y: 20 }}
              transition={{ type: "spring", damping: 20, stiffness: 300 }}
              className="glass-panel rounded-[2rem] p-8 md:p-10 max-w-md w-full text-center border border-primary/20 relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setShowAlreadyActive(false)}
                className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute -top-20 -right-20 w-60 h-60 bg-primary/10 blur-[80px] rounded-full pointer-events-none"></div>

              <div className="w-20 h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-5 shadow-[0_0_40px_rgba(var(--primary),0.2)] border border-primary/20">
                <Crown className="w-10 h-10 text-primary" />
              </div>

              <h3 className="text-2xl font-bold text-foreground mb-3">
                {t("checkout.popup.active.title")}
              </h3>
              <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
                {t("checkout.popup.active.desc")}
              </p>

              <div className="flex flex-col gap-3">
                <div className="flex gap-2">
                  <a
                    href="https://t.me/zakarya_op"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="smooth-button flex-1 bg-primary text-primary-foreground font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2"
                    data-testid="button-go-portal-active"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L7.41 13.946l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.738.613z"/></svg>
                    Telegram
                  </a>
                  <a
                    href="https://wa.me/923192530306"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="smooth-button flex-1 bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 transition-colors"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    WhatsApp
                  </a>
                </div>
                <button
                  onClick={() => setShowAlreadyActive(false)}
                  className="w-full bg-card/30 hover:bg-card/40 text-muted-foreground font-medium py-3 rounded-xl text-sm transition-colors border border-border"
                  data-testid="button-close-active-popup"
                >
                  {t("checkout.popup.active.close")}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showPendingPopup && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/70 backdrop-blur-sm"
            onClick={() => setShowPendingPopup(false)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.85, opacity: 0, y: 20 }}
              transition={{ type: "spring", damping: 20, stiffness: 300 }}
              className="glass-panel rounded-[2rem] p-8 md:p-10 max-w-md w-full text-center border border-yellow-500/20 relative overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setShowPendingPopup(false)}
                className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute -top-20 -right-20 w-60 h-60 bg-yellow-500/10 blur-[80px] rounded-full pointer-events-none"></div>

              <div className="w-20 h-20 mx-auto bg-yellow-500/10 rounded-full flex items-center justify-center mb-5 shadow-[0_0_40px_rgba(234,179,8,0.15)] border border-yellow-500/20">
                <AlertTriangle className="w-10 h-10 text-yellow-500" />
              </div>

              <h3 className="text-2xl font-bold text-foreground mb-3">
                {t("checkout.popup.pending.title")}
              </h3>
              <p className="text-muted-foreground text-sm mb-6 leading-relaxed">
                {t("checkout.popup.pending.desc")}
              </p>

              <div className="flex flex-col gap-3">
                <button
                  onClick={() => setLocation("/portal")}
                  className="smooth-button w-full bg-yellow-500 text-black font-bold py-3.5 rounded-xl text-sm"
                  data-testid="button-go-portal-pending"
                >
                  {t("checkout.popup.pending.button")}
                </button>
                <button
                  onClick={() => setShowPendingPopup(false)}
                  className="w-full bg-card/30 hover:bg-card/40 text-muted-foreground font-medium py-3 rounded-xl text-sm transition-colors border border-border"
                  data-testid="button-close-pending-popup"
                >
                  {t("checkout.popup.pending.close")}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
