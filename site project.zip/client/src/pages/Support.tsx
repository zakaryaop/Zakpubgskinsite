import { motion } from "framer-motion";
import { Link } from "wouter";
import { Headphones, ArrowLeft, MessageCircle, Clock, HelpCircle, Send, Mail, Globe } from "lucide-react";

const fadeUp = { initial: { opacity: 0, y: 20 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true } };

const faqs = [
  {
    q: "How long does payment verification take?",
    a: "Payment verification typically takes 5-15 minutes. Our admin team reviews each payment manually to ensure security."
  },
  {
    q: "What if my payment was rejected?",
    a: "If your payment was rejected, it may be due to an incorrect screenshot or payment amount. You can resubmit with the correct details from the checkout page."
  },
  {
    q: "Can I change my membership plan?",
    a: "Currently, plan changes are not supported mid-subscription. You can choose a different plan when your current membership expires."
  },
  {
    q: "How do I access VIP files?",
    a: "After your payment is approved, log in to the Client Portal using your Telegram ID. All VIP files, configs, and guides will be available in your dashboard."
  },
  {
    q: "What payment methods are supported?",
    a: "We support 30+ payment methods across 11 countries including PayPal, Binance, Easypaisa, JazzCash, UPI, bKash, Vodafone Cash, and many more regional options."
  },
  {
    q: "Can I get a refund?",
    a: "Due to the digital nature of our products, all sales are final once membership is activated. Please review our Terms of Service for more details."
  },
  {
    q: "My membership expired. How do I renew?",
    a: "Simply go to the Memberships section and select your preferred plan. Complete the checkout process again to renew your VIP access."
  },
  {
    q: "Is sharing my VIP files allowed?",
    a: "No. Sharing VIP content or account credentials with non-members is strictly prohibited and will result in immediate membership termination."
  }
];

export default function Support() {
  return (
    <div className="min-h-screen pt-24 pb-10 px-6">
      <div className="container mx-auto max-w-3xl">
        <motion.div {...fadeUp}>
          <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors text-sm mb-8" data-testid="link-back-home">
            <ArrowLeft className="w-4 h-4" /> Back to Home
          </Link>

          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
              <Headphones className="w-7 h-7 text-blue-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-foreground font-heading" data-testid="text-support-title">Support Center</h1>
              <p className="text-muted-foreground text-sm mt-1">We're here to help you 24/7</p>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-4 mb-6">
          {[
            {
              icon: <MessageCircle className="w-5 h-5" />,
              title: "Telegram Support",
              desc: "Chat with us directly",
              link: "https://t.me/Zaksite_bot",
              color: "text-[#2AABEE]",
              bg: "bg-[#2AABEE]/10 border-[#2AABEE]/20"
            },
            {
              icon: <Clock className="w-5 h-5" />,
              title: "Response Time",
              desc: "Usually within 5-15 min",
              color: "text-primary",
              bg: "bg-primary/10 border-primary/20"
            },
            {
              icon: <Globe className="w-5 h-5" />,
              title: "Available 24/7",
              desc: "Support in multiple languages",
              color: "text-green-400",
              bg: "bg-green-500/10 border-green-500/20"
            }
          ].map((item, i) => (
            <motion.div
              key={i}
              {...fadeUp}
              transition={{ delay: i * 0.1 }}
              className="glass-panel rounded-2xl p-5 border border-border"
            >
              <div className={`w-10 h-10 rounded-xl ${item.bg} border flex items-center justify-center mb-3`}>
                <span className={item.color}>{item.icon}</span>
              </div>
              <h3 className="text-foreground font-bold text-sm mb-1">{item.title}</h3>
              <p className="text-muted-foreground text-xs">{item.desc}</p>
              {item.link && (
                <a href={item.link} target="_blank" rel="noopener noreferrer" className={`${item.color} text-xs font-medium mt-2 inline-flex items-center gap-1 hover:underline`}>
                  <Send className="w-3 h-3" /> Open Chat
                </a>
              )}
            </motion.div>
          ))}
        </div>

        <motion.div {...fadeUp} transition={{ delay: 0.2 }}>
          <div className="flex items-center gap-3 mb-6">
            <HelpCircle className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold text-foreground font-heading">Frequently Asked Questions</h2>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <motion.details
                key={i}
                {...fadeUp}
                transition={{ delay: 0.05 * i }}
                className="glass-panel rounded-xl border border-border group"
              >
                <summary className="flex items-center justify-between px-5 py-4 cursor-pointer text-foreground font-medium text-sm hover:text-primary transition-colors list-none">
                  <span>{faq.q}</span>
                  <span className="text-muted-foreground group-open:rotate-45 transition-transform text-lg">+</span>
                </summary>
                <div className="px-5 pb-4">
                  <p className="text-muted-foreground text-sm leading-relaxed">{faq.a}</p>
                </div>
              </motion.details>
            ))}
          </div>
        </motion.div>

        <motion.div {...fadeUp} transition={{ delay: 0.3 }} className="mt-6 glass-panel rounded-2xl p-8 text-center border border-primary/10">
          <h3 className="text-lg font-bold text-foreground mb-2">Still Need Help?</h3>
          <p className="text-muted-foreground text-sm mb-5">Our support team is always ready to assist you on Telegram.</p>
          <a
            href="https://t.me/Zaksite_bot"
            target="_blank"
            rel="noopener noreferrer"
            className="smooth-button inline-flex items-center gap-2 bg-[#2AABEE] text-white px-8 py-3 rounded-full font-bold text-sm hover:bg-[#229ED9] transition-colors"
            data-testid="button-contact-telegram"
          >
            <MessageCircle className="w-4 h-4" /> Chat on Telegram
          </a>
        </motion.div>
      </div>
    </div>
  );
}
