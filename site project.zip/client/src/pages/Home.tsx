import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Check,
  X,
  ShieldCheck,
  Zap,
  Crosshair,
  Star,
  Crown,
  Users,
  Download,
  HeadphonesIcon,
  Globe,
  ChevronDown,
  HelpCircle,
  Play,
} from "lucide-react";
import heroBg from "@/assets/images/hero-bg.webp";
import { useI18n } from "@/lib/i18n";
import {
  PayPalIcon,
  BinanceIcon,
  USDTIcon,
  EasypaisaIcon,
  JazzCashIcon,
  GooglePayIcon,
  BkashIcon,
  STCPayIcon,
  WiseIcon,
  SkrillIcon,
} from "@/components/PaymentIcons";

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1,
    },
  },
};

const staggerItem = {
  hidden: { opacity: 0, y: 24, scale: 0.97 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as const },
  },
};


function FloatingParticles() {
  const particles = Array.from({ length: 8 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    bottom: `${-10 - Math.random() * 20}%`,
    duration: 8 + Math.random() * 12,
    delay: Math.random() * 8,
    size: 1 + Math.random() * 3,
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none z-[1]">
      {particles.map((p) => (
        <div
          key={p.id}
          className="particle"
          style={{
            left: p.left,
            bottom: p.bottom,
            width: `${p.size}px`,
            height: `${p.size}px`,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
          }}
        />
      ))}
    </div>
  );
}


function useCountUp(target: number, duration: number = 2000, startOnView: boolean = true) {
  const [count, setCount] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!startOnView || hasStarted) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setHasStarted(true); },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [startOnView, hasStarted]);

  useEffect(() => {
    if (!hasStarted) return;
    let startTime: number;
    let rafId: number;
    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(progress >= 1 ? target : Math.floor(eased * target));
      if (progress < 1) rafId = requestAnimationFrame(animate);
    };
    rafId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafId);
  }, [hasStarted, target, duration]);

  return { count, ref };
}

function AnimatedStat({ value, label, icon: Icon }: { value: string; label: string; icon: any }) {
  const numMatch = value.match(/(\d+\.?\d*)/);
  const num = numMatch ? parseFloat(numMatch[1]) : 0;
  const suffix = value.replace(/[\d.]/g, "");
  const isDecimal = value.includes(".");
  const { count, ref } = useCountUp(num, 1800);

  return (
    <motion.div variants={staggerItem} className="text-center" ref={ref}>
      <div className="flex justify-center mb-3">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/20 sparkle-effect relative">
          <Icon className="w-5 h-5 text-primary" />
        </div>
      </div>
      <div className="text-sm md:text-base font-extrabold text-foreground mb-1 stat-number">
        {isDecimal ? count.toFixed(1) : count}{suffix}
      </div>
      <div className="text-xs text-muted-foreground uppercase tracking-wider font-medium">
        {label}
      </div>
    </motion.div>
  );
}



function FAQItem({ question, answer, index }: { question: string; answer: string; index: number }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      {...fadeUp}
      transition={{ delay: index * 0.05, duration: 0.5 }}
      className="glass-panel-premium rounded-2xl border border-border overflow-hidden"
      data-testid={`faq-item-${index}`}
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between gap-4 p-5 text-left hover:bg-card/30 transition-colors"
        data-testid={`faq-toggle-${index}`}
      >
        <span className="text-foreground font-semibold text-sm md:text-base">{question}</span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
          className="shrink-0"
        >
          <ChevronDown className="w-5 h-5 text-muted-foreground" />
        </motion.div>
      </button>
      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 text-muted-foreground text-sm leading-relaxed font-light border-t border-border pt-4">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function Home() {
  const { t } = useI18n();
  const heroRef = useRef<HTMLElement>(null);

  return (
    <div className="min-h-screen">
      <section ref={heroRef} className="relative min-h-[70vh] flex items-center justify-center pt-16 pb-4 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={heroBg}
            alt="Premium Gaming Background"
            className="w-full h-full object-cover opacity-40 mix-blend-screen"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/10 via-background/60 to-background"></div>
          <div className="absolute top-1/3 left-1/3 w-[400px] h-[400px] bg-primary/10 rounded-full blur-[60px] pointer-events-none glow-orb"></div>
          <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] bg-primary/8 rounded-full blur-[50px] pointer-events-none glow-orb-delayed"></div>
        </div>
        <FloatingParticles />

        <div className="container mx-auto px-6 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
            className="max-w-4xl mx-auto flex flex-col items-center"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-2 mb-6 px-5 py-2 rounded-full bg-card/30 border border-border backdrop-blur-md"
            >
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
              <span
                className="text-muted-foreground text-sm font-medium tracking-wide"
                data-testid="text-hero-badge"
              >
                {t("hero.badge")}
              </span>
            </motion.div>

            <h1
              className="text-xl md:text-3xl font-extrabold text-foreground mb-4 leading-[1.1] tracking-tight"
              data-testid="text-hero-title"
            >
              {t("hero.title1")} <br className="hidden md:block" />
              <span className="premium-text-gradient">
                {t("hero.title2")}
              </span>{" "}
              {t("hero.title3")}
            </h1>

            <p
              className="text-sm md:text-base text-muted-foreground mb-6 max-w-2xl mx-auto font-light leading-relaxed"
              data-testid="text-hero-desc"
            >
              {t("hero.desc")}
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-4 justify-center">
              <a
                href="#vip-plans"
                className="luxury-button bg-yellow-400 hover:bg-yellow-300 text-gray-900 px-8 py-3.5 rounded-full font-bold text-sm w-full sm:w-auto text-center flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(234,179,8,0.5)] transition-colors"
                data-testid="button-get-vip"
              >
                <Crown className="w-4 h-4" />
                {t("nav.getVip")}
              </a>
              <Link
                href="/demos"
                className="flex items-center justify-center gap-2 border border-border bg-card/40 backdrop-blur-md hover:border-primary/40 hover:bg-card/60 text-foreground px-8 py-3.5 rounded-full font-bold text-sm w-full sm:w-auto transition-all"
              >
                <Play className="w-4 h-4 text-primary" />
                {t("hero.demoVideos")}
              </Link>
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-background to-transparent pointer-events-none"></div>
      </section>

      <div className="premium-divider max-w-lg mx-auto" />

      <section className="py-6 relative overflow-hidden">
        <div className="container mx-auto px-6">
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto"
          >
            {[
              { value: "500+", label: t("stats.vipMembers"), icon: Users },
              { value: "99.9%", label: t("stats.uptime"), icon: Zap },
              {
                value: "24/7",
                label: t("stats.support"),
                icon: HeadphonesIcon,
              },
              { value: "15+", label: t("stats.countries"), icon: Globe },
            ].map((stat, i) => (
              <AnimatedStat key={i} value={stat.value} label={stat.label} icon={stat.icon} />
            ))}
          </motion.div>
        </div>
      </section>
      <section
        id="vip-plans"
        className="py-8 relative bg-card/20 border-y border-border"
      >
        <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-primary/5 rounded-full blur-[60px] pointer-events-none"></div>
        <div className="container mx-auto px-6 relative z-10">
          <motion.div {...fadeUp} className="text-center mb-6">
            <div className="flex justify-center mb-3">
              <Link
                href="/demos"
                className="inline-flex items-center gap-2 border border-border bg-card/40 hover:border-primary/40 hover:bg-card/60 text-foreground px-5 py-2 rounded-full font-semibold text-xs transition-all"
              >
                <Play className="w-3.5 h-3.5 text-primary" />
                {t("plans.watchDemoVideos")}
              </Link>
            </div>
            <span className="text-primary text-sm font-bold uppercase tracking-wider">
              {t("plans.tag")}
            </span>
            <h2
              className="text-xl md:text-3xl font-bold text-foreground mt-3 mb-4"
              data-testid="text-plans-title"
            >
              {t("plans.title")}{" "}
              <span className="text-primary">{t("plans.titleHighlight")}</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto font-light">
              {t("plans.subtitle")}
            </p>
          </motion.div>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-2 gap-5 max-w-4xl mx-auto"
          >
            <motion.div
              variants={staggerItem}
              className="glass-panel-premium card-3d p-6 md:p-8 rounded-3xl flex flex-col h-full hover:border-blue-500/30 border-blue-500/10 transition-all duration-500 relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-48 h-48 bg-blue-500/10 blur-[60px] rounded-full pointer-events-none"></div>
              <div className="mb-5">
                <span className="text-primary font-medium text-sm tracking-wide uppercase">
                  {t("plans.standard")}
                </span>
                <h3 className="text-3xl font-bold text-foreground mt-2">
                  {t("plans.vip30")}
                </h3>
                <div className="mt-4 flex items-baseline gap-2">
                  <span
                    className="text-5xl font-extrabold text-foreground"
                    data-testid="text-price-30"
                  >
                    $14.99
                  </span>
                  <span className="text-muted-foreground font-medium">
                    {t("plans.perMonth")}
                  </span>
                </div>
              </div>

              <div className="flex-grow relative z-10">
                <ul className="space-y-2 mb-5">
                  {[
                    { text: "Aimbot 30° to 360°", included: true },
                    { text: "CrossHair (Small - Medium)", included: true },
                    { text: "Less Recoil (Low - High)", included: true },
                    { text: "IPad View 10% to 100%", included: true },
                    { text: "Chat-Support 24/7 Online", included: true },
                    { text: "Live Apply File Guide", included: true },
                    { text: "Main Account 100% Guarantee", included: true },
                    { text: "Player Speed (Low - High)", included: false },
                    { text: "Magic Bullet (Low - High)", included: false },
                    { text: "High Damage (Low - High)", included: false },
                    { text: "Single Anteena (Enemy Location)", included: false },
                    { text: "Customized Features You Select", included: false },
                    { text: "Every 3 Days File Update", included: false },
                    { text: "Full Season Access", included: false },
                  ].map((feature, i) => (
                    <li
                      key={i}
                      className={`flex items-center gap-3 text-sm ${feature.included ? "text-muted-foreground" : "text-muted-foreground line-through"}`}
                    >
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 ${feature.included ? "bg-primary/20" : "bg-card/30"}`}>
                        {feature.included ? <Check className="w-3 h-3 text-primary" /> : <X className="w-3 h-3 text-muted-foreground" />}
                      </div>
                      {feature.text}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-col gap-2 mt-auto">
                <Link
                  href="/demos"
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm bg-teal-600 hover:bg-teal-500 text-white shadow-[0_0_14px_rgba(13,148,136,0.35)] hover:shadow-[0_0_20px_rgba(13,148,136,0.5)] transition-all"
                >
                  <Play className="w-4 h-4" />
                  {t("plans.watchDemoVideos")}
                </Link>
                <Link
                  href="/checkout/30-days"
                  className="luxury-button w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm bg-yellow-400 hover:bg-yellow-300 text-gray-900 shadow-[0_0_16px_rgba(234,179,8,0.4)] transition-colors"
                  data-testid="link-select-30"
                >
                  <Crown className="w-4 h-4" />
                  {t("plans.select30")}
                </Link>
              </div>
            </motion.div>

            <motion.div
              variants={staggerItem}
              className="glass-panel-premium card-3d gradient-border p-6 md:p-8 rounded-3xl flex flex-col h-full border-primary/30 relative overflow-hidden hover:border-primary/50 transition-all duration-500"
            >
              <div className="absolute top-0 right-0 w-48 h-48 bg-primary/8 blur-[40px] rounded-full pointer-events-none"></div>

              <div className="absolute top-6 right-6 flex items-center gap-1 bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-bold border border-primary/20">
                <Star className="w-3 h-3 fill-primary text-primary" />{" "}
                {t("plans.bestValue")}
              </div>

              <div className="mb-5 relative z-10">
                <span className="text-primary font-medium text-sm tracking-wide uppercase">
                  {t("plans.elite")}
                </span>
                <h3 className="text-3xl font-bold text-foreground mt-2">
                  {t("plans.vip60")}
                </h3>
                <div className="mt-4 flex items-baseline gap-2">
                  <span
                    className="text-5xl font-extrabold text-foreground"
                    data-testid="text-price-60"
                  >
                    $24.99
                  </span>
                  <span className="text-muted-foreground font-medium">
                    {t("plans.per2Months")}
                  </span>
                </div>
                <p className="text-sm text-green-400 font-medium mt-2">
                  {t("plans.save")}
                </p>
              </div>

              <div className="flex-grow relative z-10">
                <ul className="space-y-2 mb-5">
                  {[
                    "Aimbot 30° to 360°",
                    "CrossHair (Small - Medium)",
                    "Player Speed (Low - High)",
                    "Less Recoil (Low - High)",
                    "Magic Bullet (Low - High)",
                    "High Damage (Low - High)",
                    "Single Anteena (Enemy Location)",
                    "IPad View 10% to 100%",
                    "Every 3 Days File Update",
                    "Customized Features You Select",
                    "Chat-Support 24/7 Online",
                    "Live Apply File Properly Guide",
                    "Main Account 100% Guarantee",
                    "Full Season Access",
                  ].map((feature, i) => (
                    <li
                      key={i}
                      className="flex items-center gap-3 text-foreground text-sm font-medium"
                    >
                      <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center shrink-0">
                        <Check className="w-3 h-3 text-primary-foreground" />
                      </div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex flex-col gap-2 mt-auto relative z-10">
                <Link
                  href="/demos"
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm bg-teal-600 hover:bg-teal-500 text-white shadow-[0_0_14px_rgba(13,148,136,0.35)] hover:shadow-[0_0_20px_rgba(13,148,136,0.5)] transition-all"
                >
                  <Play className="w-4 h-4" />
                  {t("plans.watchDemoVideos")}
                </Link>
                <Link
                  href="/checkout/60-days"
                  className="luxury-button w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm bg-yellow-400 hover:bg-yellow-300 text-gray-900 shadow-[0_0_16px_rgba(234,179,8,0.4)] transition-colors"
                  data-testid="link-select-60"
                >
                  <Crown className="w-4 h-4" />
                  {t("plans.select60")}
                </Link>
              </div>
            </motion.div>
          </motion.div>

          <motion.div
            {...fadeUp}
            className="mt-8 text-center"
          >
            <p className="text-xs text-muted-foreground uppercase tracking-widest font-medium mb-4">
              {t("plans.acceptedPayments")}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3 max-w-lg mx-auto">
              {[
                { icon: PayPalIcon, name: "PayPal" },
                { icon: BinanceIcon, name: "Binance" },
                { icon: USDTIcon, name: "USDT" },
                { icon: EasypaisaIcon, name: "Easypaisa" },
                { icon: JazzCashIcon, name: "JazzCash" },
                { icon: GooglePayIcon, name: "Google Pay" },
                { icon: BkashIcon, name: "bKash" },
                { icon: STCPayIcon, name: "STC Pay" },
                { icon: WiseIcon, name: "Wise" },
                { icon: SkrillIcon, name: "Skrill" },
              ].map((pm) => (
                <div
                  key={pm.name}
                  className="flex items-center gap-1.5 bg-card/30 border border-border rounded-lg px-2.5 py-1.5 hover:border-primary/30 transition-all"
                  title={pm.name}
                >
                  <pm.icon className="w-5 h-5" />
                  <span className="text-[11px] text-muted-foreground font-medium">{pm.name}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
      <div className="premium-divider max-w-lg mx-auto" />

      <section id="features" className="py-8 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[300px] bg-primary/5 rounded-full blur-[60px] pointer-events-none"></div>
        <div className="container mx-auto px-6 relative z-10">
          <motion.div {...fadeUp} className="text-center mb-6">
            <span className="text-primary text-sm font-bold uppercase tracking-wider">
              {t("features.tag")}
            </span>
            <h2
              className="text-xl md:text-3xl font-bold text-foreground mt-3 mb-4"
              data-testid="text-features-title"
            >
              {t("features.title")}{" "}
              <span className="text-primary">
                {t("features.titleHighlight")}
              </span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto font-light">
              {t("features.subtitle")}
            </p>
          </motion.div>

          <motion.div
            variants={staggerContainer}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto"
          >
            {[
              {
                icon: ShieldCheck,
                title: t("features.security.title"),
                desc: t("features.security.desc"),
              },
              {
                icon: Zap,
                title: t("features.latency.title"),
                desc: t("features.latency.desc"),
              },
              {
                icon: Crosshair,
                title: t("features.precision.title"),
                desc: t("features.precision.desc"),
              },
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                variants={staggerItem}
                className="glass-panel-premium p-6 rounded-3xl group hover:border-primary/20 transition-all duration-500 card-3d"
              >
                <div className="mb-4 w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center border border-primary/20 group-hover:bg-primary/20 group-hover:scale-110 group-hover:shadow-[0_0_25px_hsl(var(--primary)/0.2)] transition-all duration-500">
                  <feature.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground font-light leading-relaxed">
                  {feature.desc}
                </p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>
      <div className="premium-divider max-w-lg mx-auto" />

      <section id="faq" className="py-8 relative overflow-hidden">
        <div className="absolute top-0 right-1/4 w-[300px] h-[300px] bg-primary/5 rounded-full blur-[60px] pointer-events-none"></div>
        <div className="container mx-auto px-6 relative z-10">
          <motion.div {...fadeUp} className="text-center mb-6">
            <span className="inline-flex items-center gap-2 text-primary text-sm font-bold uppercase tracking-wider mb-2">
              <HelpCircle className="w-4 h-4" />
              {t("faq.tag")}
            </span>
            <h2 className="text-xl md:text-3xl font-bold text-foreground mt-3 mb-4" data-testid="text-faq-title">
              {t("faq.title")}{" "}
              <span className="text-primary">{t("faq.titleHighlight")}</span>
            </h2>
          </motion.div>

          <div className="max-w-3xl mx-auto space-y-3">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
              <FAQItem
                key={num}
                question={t(`faq.q${num}`)}
                answer={t(`faq.a${num}`)}
                index={num}
              />
            ))}
          </div>
        </div>
      </section>

      <div className="premium-divider max-w-lg mx-auto" />

      <section className="py-10 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/[0.02] to-transparent pointer-events-none"></div>
        <div className="container mx-auto px-6 text-center relative z-10">
          <motion.div {...fadeUp} className="max-w-2xl mx-auto">
            <div className="relative inline-block mb-4">
              <Crown className="w-12 h-12 text-primary mx-auto" />
              <div className="absolute inset-0 w-12 h-12 mx-auto bg-primary/20 rounded-full blur-xl"></div>
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-foreground mb-3">
              {t("cta.title")}
            </h2>
            <p className="text-muted-foreground mb-6 font-light">{t("cta.desc")}</p>
            <a
              href="#vip-plans"
              className="luxury-button inline-flex items-center gap-2 bg-yellow-400 hover:bg-yellow-300 text-gray-900 px-10 py-4 rounded-full font-bold text-base shadow-[0_0_24px_rgba(234,179,8,0.5)] transition-colors"
              data-testid="button-cta-bottom"
            >
              <Crown className="w-5 h-5" />
              {t("cta.button")}
            </a>
          </motion.div>
        </div>
      </section>

      <footer className="py-6 bg-background">
        <div className="premium-divider mb-6" />
        <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4 pt-2">
          <div className="flex items-center gap-2">
            <Crown className="text-primary w-5 h-5" />
            <span className="font-heading font-bold text-lg text-foreground">
              ZakPubg<span className="text-primary">Skin</span>
            </span>
          </div>
          <div className="flex gap-6 text-sm text-muted-foreground font-light">
            <Link
              href="/terms"
              className="hover:text-primary transition-colors"
            >
              {t("footer.terms")}
            </Link>
            <Link
              href="/privacy"
              className="hover:text-primary transition-colors"
            >
              {t("footer.privacy")}
            </Link>
            <Link
              href="/support"
              className="hover:text-primary transition-colors"
            >
              {t("footer.support")}
            </Link>
          </div>
          <div className="text-xs text-muted-foreground font-light">
            {t("footer.copyright")}
          </div>
        </div>
      </footer>
    </div>
  );
}
