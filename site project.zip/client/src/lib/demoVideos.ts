export interface DemoVideo {
  id: number;
  title: string;
  desc: string;
  tag: string;
  embedUrl: string;
}

export const demoVideos: DemoVideo[] = [
  {
    id: 1,
    title: "Aimbot Config",
    desc: "Auto-locks onto enemies with pinpoint precision — zero missed shots.",
    tag: "Aimbot",
    embedUrl: "https://www.youtube.com/embed/ldj9SZm1kGk",
  },
  {
    id: 2,
    title: "Aimbot + Antenna Config",
    desc: "Aimbot combined with antenna boost for extended range and instant lock-on.",
    tag: "Aimbot + Antenna",
    embedUrl: "https://www.youtube.com/embed/cbWEhAAu2js",
  },
  {
    id: 3,
    title: "Headshot Config",
    desc: "Every bullet finds the head — dominate every engagement instantly.",
    tag: "Headshot",
    embedUrl: "https://www.youtube.com/embed/X9PuRSWwBpc",
  },
  {
    id: 4,
    title: "Magic Bullet",
    desc: "Bullets connect even through obstacles — consistent damage every round.",
    tag: "Magic Bullet",
    embedUrl: "https://www.youtube.com/embed/Oi7u7SaVvXs",
  },
  {
    id: 5,
    title: "Antenna + Magic Bullet",
    desc: "Combined antenna boost and magic bullet for maximum range and impact.",
    tag: "Antenna",
    embedUrl: "https://www.youtube.com/embed/d3mxven3oZE",
  },
];
