const API_BASE = "/api";

function getSessionToken(): string | null {
  return localStorage.getItem("zakpubg_session_token");
}

export function setSessionToken(token: string | null) {
  if (token) {
    localStorage.setItem("zakpubg_session_token", token);
  } else {
    localStorage.removeItem("zakpubg_session_token");
  }
}

export function getDeviceId(): string {
  let deviceId = localStorage.getItem("zakpubg_device_id");
  if (!deviceId) {
    const nav = navigator;
    const screen = window.screen;
    const raw = [
      nav.userAgent,
      nav.language,
      screen.width + "x" + screen.height,
      screen.colorDepth,
      Intl.DateTimeFormat().resolvedOptions().timeZone,
      nav.hardwareConcurrency || 0,
      Date.now().toString(36),
      Math.random().toString(36).substring(2),
    ].join("|");
    let hash = 0;
    for (let i = 0; i < raw.length; i++) {
      const char = raw.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash |= 0;
    }
    deviceId = "dev_" + Math.abs(hash).toString(36) + "_" + Date.now().toString(36);
    localStorage.setItem("zakpubg_device_id", deviceId);
  }
  return deviceId;
}

export async function submitPayment(data: {
  telegramId: string;
  plan: string;
  country: string;
  paymentMethod: string;
  screenshot: File | null;
  giftCardCode?: string;
  referralCode?: string;
}) {
  const formData = new FormData();
  formData.append("telegramId", data.telegramId);
  formData.append("plan", data.plan);
  formData.append("country", data.country);
  formData.append("paymentMethod", data.paymentMethod);
  if (data.screenshot) {
    formData.append("screenshot", data.screenshot);
  }
  if (data.giftCardCode) {
    formData.append("giftCardCode", data.giftCardCode);
  }
  if (data.referralCode) {
    formData.append("referralCode", data.referralCode);
  }

  const res = await fetch(`${API_BASE}/payment-submit`, {
    method: "POST",
    body: formData,
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || "Failed to submit payment");
  }
  return res.json();
}

export async function loginMember(username: string, password: string) {
  const deviceId = getDeviceId();
  const res = await fetch(`${API_BASE}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password, deviceId }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || "Login failed");
  }
  const data = await res.json();
  if (data.sessionToken) {
    setSessionToken(data.sessionToken);
  }
  return data;
}

export async function logoutMember() {
  const token = getSessionToken();
  if (token) {
    await fetch(`${API_BASE}/logout`, {
      method: "POST",
      headers: { "x-session-token": token },
    });
  }
  setSessionToken(null);
}

export async function validateSession() {
  const token = getSessionToken();
  if (!token) return null;
  try {
    const res = await fetch(`${API_BASE}/session/validate`, {
      headers: { "x-session-token": token },
    });
    if (!res.ok) {
      setSessionToken(null);
      return null;
    }
    const data = await res.json();
    if (data.valid && data.member) {
      return data.member;
    }
    setSessionToken(null);
    return null;
  } catch {
    return null;
  }
}

export async function getMember(id: number) {
  const res = await fetch(`${API_BASE}/member/${id}`);
  if (!res.ok) throw new Error("Member not found");
  return res.json();
}

export async function adminLogin(username: string, password: string) {
  const res = await fetch(`${API_BASE}/admin/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password }),
  });
  if (!res.ok) throw new Error("Invalid credentials");
  return res.json();
}

export async function getPendingMembers(token: string) {
  const res = await fetch(`${API_BASE}/admin/pending`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Unauthorized");
  return res.json();
}

export async function getActiveMembers(token: string) {
  const res = await fetch(`${API_BASE}/admin/active`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Unauthorized");
  return res.json();
}

export async function approveMember(id: number, token: string) {
  const res = await fetch(`${API_BASE}/admin/approve/${id}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Failed to approve");
  return res.json();
}

export async function rejectMember(id: number, token: string) {
  const res = await fetch(`${API_BASE}/admin/reject/${id}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Failed to reject");
  return res.json();
}

export async function getAdminStats(token: string) {
  const res = await fetch(`${API_BASE}/admin/stats`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Unauthorized");
  return res.json();
}

export async function getAllMembers(token: string) {
  const res = await fetch(`${API_BASE}/admin/all`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Unauthorized");
  return res.json();
}
