import { pgTable, text, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const members = pgTable("members", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  username: text("username").unique(),
  passwordHash: text("password_hash"),
  telegramId: text("telegram_id").notNull(),
  plan: text("plan").notNull(),
  country: text("country").notNull(),
  paymentMethod: text("payment_method").notNull(),
  screenshotUrl: text("screenshot_url"),
  status: text("status").notNull().default("pending"),
  expiryDate: timestamp("expiry_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  referralCode: text("referral_code").unique(),
  referredBy: text("referred_by"),
  expiryNotified: boolean("expiry_notified").default(false),
  telegramChatId: text("telegram_chat_id"),
  giftCardCode: text("gift_card_code"),
  boundDeviceId: text("bound_device_id"),
  lastLoginIp: text("last_login_ip"),
  lastLoginAt: timestamp("last_login_at"),
  blocked: boolean("blocked").default(false),
  loginKey: text("login_key").unique(),
});

export const loginAttempts = pgTable("login_attempts", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  telegramId: text("telegram_id").notNull(),
  ip: text("ip").notNull(),
  deviceId: text("device_id"),
  success: boolean("success").notNull().default(false),
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const secureDownloads = pgTable("secure_downloads", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  token: text("token").notNull().unique(),
  memberId: integer("member_id").notNull(),
  fileName: text("file_name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
});

export const sessions = pgTable("sessions", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  token: text("token").notNull().unique(),
  memberId: integer("member_id").notNull(),
  deviceId: text("device_id").notNull(),
  ip: text("ip"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const admins = pgTable("admins", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertMemberSchema = createInsertSchema(members).omit({
  id: true,
  status: true,
  expiryDate: true,
  createdAt: true,
  referralCode: true,
  expiryNotified: true,
});

export const paymentSubmitSchema = z.object({
  telegramId: z.string().min(2),
  plan: z.enum(["30-days", "60-days"]),
  country: z.string().min(1),
  paymentMethod: z.string().min(1),
  giftCardCode: z.string().optional(),
  referralCode: z.string().optional(),
});

export const vipBotUsers = pgTable("vip_bot_users", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  telegramId: text("telegram_id").notNull().unique(),
  telegramUsername: text("telegram_username"),
  telegramName: text("telegram_name"),
  plan: text("plan"),
  paymentMethod: text("payment_method"),
  screenshotFileId: text("screenshot_file_id"),
  status: text("status").notNull().default("pending"),
  expiryDate: timestamp("expiry_date"),
  inviteLink: text("invite_link"),
  invitedToGroup: boolean("invited_to_group").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  approvedAt: timestamp("approved_at"),
});

export type VipBotUser = typeof vipBotUsers.$inferSelect;

export type InsertMember = z.infer<typeof insertMemberSchema>;
export type Member = typeof members.$inferSelect;
export type Admin = typeof admins.$inferSelect;
