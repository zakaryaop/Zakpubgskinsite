import fs from "fs";
import FormData from "form-data";

const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || process.env.VIPBOT_TOKEN;
const CHAT_ID = process.env.TELEGRAM_CHAT_ID || process.env.VIPBOT_ADMIN_CHAT_ID;

async function sendMsg(chatId: string | number, text: string, replyMarkup?: any): Promise<boolean> {
  if (!BOT_TOKEN) { console.error("Telegram: BOT_TOKEN not set"); return false; }
  try {
    const body: any = { chat_id: chatId, text, parse_mode: "Markdown" };
    if (replyMarkup) body.reply_markup = replyMarkup;
    const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!data.ok) {
      console.error("Telegram sendMsg failed:", JSON.stringify(data));
      const plainRes = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: chatId, text: text.replace(/[*`_\\]/g, ""), reply_markup: replyMarkup }),
      });
      const plainData = await plainRes.json();
      return plainData.ok;
    }
    return true;
  } catch (err) {
    console.error("Telegram sendMsg error:", err);
    return false;
  }
}

export async function sendPaymentRequest(data: {
  telegramId: string;
  username: string;
  plan: string;
  country: string;
  paymentMethod: string;
  memberId: number;
  screenshotPath?: string;
  giftCardCode?: string;
}) {
  if (!BOT_TOKEN || !CHAT_ID) return false;

  const planLabel = data.plan === "60-days" ? "VIP 60 Days" : "VIP 30 Days";
  const safeTgId = data.telegramId.replace(/[_*`[\]()~>#+=|{}.!-]/g, "\\$&");
  let caption = `🎮 *NEW PAYMENT REQUEST*\n\n` +
    `👤 Telegram ID: \`${data.telegramId}\`\n` +
    `📦 Plan: *${planLabel}*\n` +
    `🌍 Country: ${data.country}\n` +
    `💳 Payment: ${data.paymentMethod}\n` +
    `🆔 Order: #${data.memberId}`;
  if (data.giftCardCode) {
    caption += `\n🎁 Gift Card: \`${data.giftCardCode}\``;
  }

  const markup = JSON.stringify({
    inline_keyboard: [[
      { text: "✅ Approve", callback_data: `vipapprove_${data.telegramId}` },
      { text: "❌ Reject",  callback_data: `vipreject_${data.telegramId}`  },
    ]],
  });

  try {
    if (data.screenshotPath && fs.existsSync(data.screenshotPath)) {
      try {
        const form = new FormData();
        form.append("chat_id", CHAT_ID);
        form.append("photo", fs.createReadStream(data.screenshotPath));
        form.append("caption", caption);
        form.append("parse_mode", "Markdown");
        form.append("reply_markup", markup);
        const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`, {
          method: "POST",
          body: form as any,
          headers: form.getHeaders(),
        });
        const text = await res.text();
        try {
          const result = JSON.parse(text);
          if (result.ok) return true;
          console.error("Telegram sendPhoto failed:", text);
        } catch {
          console.error("Telegram sendPhoto non-JSON response:", text.substring(0, 200));
        }
      } catch (photoErr) {
        console.error("Telegram sendPhoto error:", photoErr);
      }
    }

    const msgRes = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: CHAT_ID, text: caption, parse_mode: "Markdown", reply_markup: JSON.parse(markup) }),
    });
    const msgResult = await msgRes.json();
    if (msgResult.ok) return true;
    console.error("Telegram sendMessage failed:", JSON.stringify(msgResult));

    const plainRes = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: CHAT_ID, text: caption.replace(/[*`_]/g, ""), reply_markup: JSON.parse(markup) }),
    });
    const plainResult = await plainRes.json();
    if (plainResult.ok) return true;
    console.error("Telegram plain sendMessage also failed:", JSON.stringify(plainResult));
    return false;
  } catch (err) {
    console.error("Telegram notification error:", err);
    return false;
  }
}

export async function notifyUser(userChatId: string | null | undefined, text: string) {
  if (userChatId) await sendMsg(userChatId, text);
}

export async function notifyAdmin(text: string) {
  if (CHAT_ID) await sendMsg(CHAT_ID, text);
}

export async function generateGroupInviteLink(userId: string): Promise<string | null> {
  const groupId = process.env.VIP_GROUP_ID;
  if (!BOT_TOKEN || !groupId) return null;
  try {
    const expireDate = Math.floor(Date.now() / 1000) + 300;
    const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/createChatInviteLink`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: groupId, member_limit: 1, expire_date: expireDate, name: `VIP-${userId}` }),
    });
    const data = await res.json();
    return data.ok ? data.result.invite_link : null;
  } catch {
    return null;
  }
}

export async function sendExpiryNotification(chatId: string, plan: string, daysLeft: number) {
  const label = plan === "60-days" ? "VIP 60 Days" : "VIP 30 Days";
  const when = daysLeft <= 0 ? "expires TODAY" : `expires in ${daysLeft} day${daysLeft > 1 ? "s" : ""}`;
  await sendMsg(chatId, `⏰ Your *${label}* ${when}!\n\nRenew on the website.`);
}

function adminDashboardMarkup() {
  return {
    inline_keyboard: [
      [
        { text: "📋 All Users", callback_data: "admin_users_1" },
        { text: "⏳ Pending", callback_data: "admin_pending" },
      ],
      [
        { text: "➕ Add User", callback_data: "admin_add_help" },
        { text: "🗑️ Delete User", callback_data: "admin_delete_help" },
      ],
      [
        { text: "🔑 Reset Password", callback_data: "admin_resetpw_help" },
        { text: "👁️ View User", callback_data: "admin_view_help" },
      ],
    ],
  };
}

export interface BotCallbacks {
  onApprove: (memberId: number) => Promise<boolean>;
  onReject: (memberId: number) => Promise<boolean>;
  getAllMembers: () => Promise<any[]>;
  getPendingMembers: () => Promise<any[]>;
  getMember: (id: number) => Promise<any | undefined>;
  getMemberByUsername: (username: string) => Promise<any | undefined>;
  deleteMember: (id: number) => Promise<boolean>;
  addMember: (username: string, password: string, telegramId: string, plan: string) => Promise<any>;
  resetPassword: (id: number, newPassword: string) => Promise<any | undefined>;
}

let pollingActive = false;
let lastUpdateId = 0;

export function startTelegramPolling(callbacks: BotCallbacks) {
  if (pollingActive) return;
  pollingActive = true;

  function isAdmin(chatId: string | number): boolean {
    return String(chatId) === String(CHAT_ID);
  }

  async function poll() {
    if (!BOT_TOKEN) return;
    try {
      const url = `https://api.telegram.org/bot${BOT_TOKEN}/getUpdates?offset=${lastUpdateId + 1}&timeout=30&allowed_updates=["callback_query","message"]`;
      const response = await fetch(url, { signal: AbortSignal.timeout(35000) });
      const data = await response.json();

      if (data.ok && data.result) {
        for (const update of data.result) {
          lastUpdateId = update.update_id;

          if (update.callback_query) {
            const cbd = update.callback_query.data;
            const cid = String(update.callback_query.message?.chat?.id);
            const mid = update.callback_query.message?.message_id;

            if (cbd.startsWith("approve_")) {
              const ok = await callbacks.onApprove(parseInt(cbd.replace("approve_", "")));
              await answerCb(update.callback_query.id, ok ? "✅ Approved!" : "⚠️ Already done");
              if (cid && mid) await removeButtons(cid, mid);
            } else if (cbd.startsWith("reject_")) {
              const ok = await callbacks.onReject(parseInt(cbd.replace("reject_", "")));
              await answerCb(update.callback_query.id, ok ? "❌ Rejected!" : "⚠️ Already done");
              if (cid && mid) await removeButtons(cid, mid);
            } else if (isAdmin(cid)) {
              await handleAdminCallback(cbd, cid, update.callback_query.id, callbacks);
            } else {
              await answerCb(update.callback_query.id, "⛔ Admin only");
            }
          }

          if (update.message?.text) {
            const text = update.message.text.trim();
            const chatId = String(update.message.chat.id);

            if (isAdmin(chatId)) {
              if (text === "/start" || text === "/menu" || text === "/dashboard" || text === "/panel") {
                await sendMsg(chatId, "🎮 *ZakPubgSkin Admin Panel*\n\nChoose an option:", adminDashboardMarkup());
              } else {
                await handleAdminCommand(text, chatId, callbacks);
              }
            } else {
              await sendMsg(chatId, "👋 This bot is for admin use only.\n\nBuy VIP on the website, then login with your username & password.");
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name !== "TimeoutError" && err.name !== "AbortError") {
        console.error("Telegram polling error:", err);
      }
    }
    if (pollingActive) setTimeout(poll, 500);
  }

  poll();
  console.log("Telegram bot polling started");
}

async function handleAdminCallback(cbd: string, chatId: string, cbId: string, cb: BotCallbacks) {
  await answerCb(cbId, "");

  if (cbd.startsWith("admin_users_")) {
    const page = parseInt(cbd.replace("admin_users_", "")) || 1;
    const all = await cb.getAllMembers();
    const perPage = 10;
    const totalPages = Math.ceil(all.length / perPage) || 1;
    const start = (page - 1) * perPage;
    const pageMembers = all.slice(start, start + perPage);

    if (all.length === 0) {
      await sendMsg(chatId, "📋 No users found.", { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
      return;
    }

    let text = `📋 *All Users* (${all.length} total) — Page ${page}/${totalPages}\n\n`;
    for (const m of pageMembers) {
      const status = m.status === "active" ? "✅" : m.status === "pending" ? "⏳" : "❌";
      text += `${status} #${m.id} | \`${m.username || "—"}\` | ${m.plan} | ${m.telegramId}\n`;
    }

    const nav: any[] = [];
    if (page > 1) nav.push({ text: "⬅️ Prev", callback_data: `admin_users_${page - 1}` });
    if (page < totalPages) nav.push({ text: "Next ➡️", callback_data: `admin_users_${page + 1}` });
    const keyboard: any[][] = [];
    if (nav.length > 0) keyboard.push(nav);
    keyboard.push([{ text: "🔙 Back", callback_data: "admin_home" }]);

    await sendMsg(chatId, text, { inline_keyboard: keyboard });
  } else if (cbd === "admin_pending") {
    const pending = await cb.getPendingMembers();
    if (pending.length === 0) {
      await sendMsg(chatId, "⏳ No pending payments.", { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
      return;
    }
    let text = `⏳ *Pending Payments* (${pending.length})\n\n`;
    for (const m of pending) {
      text += `#${m.id} | \`${m.username || "—"}\` | ${m.plan} | ${m.telegramId}\n`;
    }
    text += `\nUse Approve/Reject buttons on payment messages, or type:\n\`/approve ID\` or \`/reject ID\``;
    await sendMsg(chatId, text, { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
  } else if (cbd === "admin_add_help") {
    await sendMsg(chatId, "➕ *Add User*\n\nSend command:\n`/add username password telegramId plan`\n\nExample:\n`/add ahmed pass123 @ahmed123 30-days`\n\nPlan: `30-days` or `60-days`", { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
  } else if (cbd === "admin_delete_help") {
    await sendMsg(chatId, "🗑️ *Delete User*\n\nSend command:\n`/delete ID`\n\nExample:\n`/delete 5`\n\nFind user ID from the All Users list.", { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
  } else if (cbd === "admin_resetpw_help") {
    await sendMsg(chatId, "🔑 *Reset Password*\n\nSend command:\n`/resetpw ID newpassword`\n\nExample:\n`/resetpw 5 newpass123`\n\nPassword must be at least 6 characters.", { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
  } else if (cbd === "admin_view_help") {
    await sendMsg(chatId, "👁️ *View User*\n\nSend command:\n`/view ID` or `/view username`\n\nExample:\n`/view 5`\n`/view ahmed`", { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
  } else if (cbd === "admin_home") {
    await sendMsg(chatId, "🎮 *ZakPubgSkin Admin Panel*\n\nChoose an option:", adminDashboardMarkup());
  } else if (cbd.startsWith("admin_del_confirm_")) {
    const id = parseInt(cbd.replace("admin_del_confirm_", ""));
    const ok = await cb.deleteMember(id);
    if (ok) {
      await sendMsg(chatId, `✅ User #${id} deleted successfully.`, { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
    } else {
      await sendMsg(chatId, `❌ Failed to delete user #${id}.`, { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
    }
  } else if (cbd.startsWith("admin_del_cancel_")) {
    await sendMsg(chatId, "❌ Delete cancelled.", { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
  }
}

async function handleAdminCommand(text: string, chatId: string, cb: BotCallbacks) {
  const parts = text.split(/\s+/);
  const cmd = parts[0].toLowerCase().split("@")[0];

  if (cmd === "/add") {
    if (parts.length < 5) {
      await sendMsg(chatId, "❌ Usage: `/add username password telegramId plan`\nExample: `/add ahmed pass123 @ahmed123 30-days`");
      return;
    }
    const [, username, password, telegramId, plan] = parts;
    if (!["30-days", "60-days"].includes(plan)) {
      await sendMsg(chatId, "❌ Plan must be `30-days` or `60-days`");
      return;
    }
    if (username.length < 3) {
      await sendMsg(chatId, "❌ Username must be at least 3 characters");
      return;
    }
    if (password.length < 6) {
      await sendMsg(chatId, "❌ Password must be at least 6 characters");
      return;
    }
    try {
      const member = await cb.addMember(username.toLowerCase(), password, telegramId, plan);
      const expiry = member.expiryDate ? new Date(member.expiryDate).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }) : "—";
      await sendMsg(chatId, `✅ *User Added & Approved*\n\n🆔 #${member.id}\n👤 Username: \`${member.username}\`\n🔑 Password: \`${password}\`\n📱 Telegram: ${telegramId}\n📦 Plan: ${plan}\n📅 Expires: ${expiry}`, { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
    } catch (err: any) {
      await sendMsg(chatId, `❌ Error: ${err.message || "Failed to add user"}`);
    }
  } else if (cmd === "/delete") {
    if (parts.length < 2) {
      await sendMsg(chatId, "❌ Usage: `/delete ID`\nExample: `/delete 5`");
      return;
    }
    const id = parseInt(parts[1]);
    if (isNaN(id)) {
      await sendMsg(chatId, "❌ Invalid ID. Use a number.");
      return;
    }
    const member = await cb.getMember(id);
    if (!member) {
      await sendMsg(chatId, `❌ User #${id} not found.`);
      return;
    }
    await sendMsg(chatId, `⚠️ *Confirm Delete*\n\n#${member.id} | \`${member.username || "—"}\` | ${member.telegramId} | ${member.status}\n\nAre you sure?`, {
      inline_keyboard: [[
        { text: "✅ Yes, Delete", callback_data: `admin_del_confirm_${id}` },
        { text: "❌ Cancel", callback_data: `admin_del_cancel_${id}` },
      ]],
    });
  } else if (cmd === "/resetpw") {
    if (parts.length < 3) {
      await sendMsg(chatId, "❌ Usage: `/resetpw ID newpassword`\nExample: `/resetpw 5 newpass123`");
      return;
    }
    const id = parseInt(parts[1]);
    const newPassword = parts[2];
    if (isNaN(id)) {
      await sendMsg(chatId, "❌ Invalid ID. Use a number.");
      return;
    }
    if (newPassword.length < 6) {
      await sendMsg(chatId, "❌ Password must be at least 6 characters.");
      return;
    }
    const updated = await cb.resetPassword(id, newPassword);
    if (updated) {
      await sendMsg(chatId, `✅ *Password Reset*\n\n#${updated.id} | \`${updated.username || "—"}\`\n🔑 New password: \`${newPassword}\``, { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
    } else {
      await sendMsg(chatId, `❌ User #${id} not found.`);
    }
  } else if (cmd === "/view") {
    if (parts.length < 2) {
      await sendMsg(chatId, "❌ Usage: `/view ID` or `/view username`\nExample: `/view 5` or `/view ahmed`");
      return;
    }
    const query = parts[1];
    let member;
    if (/^\d+$/.test(query)) {
      member = await cb.getMember(parseInt(query));
    } else {
      member = await cb.getMemberByUsername(query.toLowerCase());
    }
    if (!member) {
      await sendMsg(chatId, `❌ User not found: ${query}`);
      return;
    }
    const status = member.status === "active" ? "✅ Active" : member.status === "pending" ? "⏳ Pending" : "❌ " + member.status;
    const expiry = member.expiryDate ? new Date(member.expiryDate).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }) : "—";
    const blocked = member.blocked ? "🚫 YES" : "No";
    const device = member.boundDeviceId ? `\`${member.boundDeviceId.substring(0, 20)}...\`` : "Not bound";
    const lastIp = member.lastLoginIp || "—";
    const lastLogin = member.lastLoginAt ? new Date(member.lastLoginAt).toLocaleString() : "Never";
    const created = new Date(member.createdAt).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });

    let text = `👁️ *User Details*\n\n`;
    text += `🆔 ID: #${member.id}\n`;
    text += `👤 Username: \`${member.username || "—"}\`\n`;
    text += `📱 Telegram: ${member.telegramId}\n`;
    text += `📦 Plan: ${member.plan}\n`;
    text += `📊 Status: ${status}\n`;
    text += `📅 Expires: ${expiry}\n`;
    text += `🚫 Blocked: ${blocked}\n`;
    text += `📱 Device: ${device}\n`;
    text += `🌐 Last IP: ${lastIp}\n`;
    text += `🕐 Last Login: ${lastLogin}\n`;
    text += `📝 Registered: ${created}\n`;
    text += `🌍 Country: ${member.country}\n`;
    text += `💳 Payment: ${member.paymentMethod}`;

    await sendMsg(chatId, text, { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
  } else if (cmd === "/approve") {
    if (parts.length < 2) {
      await sendMsg(chatId, "❌ Usage: `/approve ID`");
      return;
    }
    const id = parseInt(parts[1]);
    if (isNaN(id)) {
      await sendMsg(chatId, "❌ Invalid ID.");
      return;
    }
    const ok = await cb.onApprove(id);
    if (ok) {
      await sendMsg(chatId, `✅ User #${id} approved!`, { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
    } else {
      await sendMsg(chatId, `⚠️ Could not approve #${id}. Already active or not found.`);
    }
  } else if (cmd === "/reject") {
    if (parts.length < 2) {
      await sendMsg(chatId, "❌ Usage: `/reject ID`");
      return;
    }
    const id = parseInt(parts[1]);
    if (isNaN(id)) {
      await sendMsg(chatId, "❌ Invalid ID.");
      return;
    }
    const ok = await cb.onReject(id);
    if (ok) {
      await sendMsg(chatId, `❌ User #${id} rejected.`, { inline_keyboard: [[{ text: "🔙 Back", callback_data: "admin_home" }]] });
    } else {
      await sendMsg(chatId, `⚠️ Could not reject #${id}. Already processed or not found.`);
    }
  }
}

async function answerCb(id: string, text: string) {
  if (!BOT_TOKEN) return;
  try {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/answerCallbackQuery`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ callback_query_id: id, text }),
    });
  } catch {}
}

async function removeButtons(chatId: string | number, messageId: number) {
  if (!BOT_TOKEN) return;
  try {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/editMessageReplyMarkup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, message_id: messageId, reply_markup: { inline_keyboard: [] } }),
    });
  } catch {}
}
