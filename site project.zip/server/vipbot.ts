import { drizzle } from "drizzle-orm/node-postgres";
import { vipBotUsers, members } from "@shared/schema";
import { eq, desc, and, lt } from "drizzle-orm";

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required");
}

const db = drizzle(process.env.DATABASE_URL);

const BOT_TOKEN = process.env.VIPBOT_TOKEN;
const ADMIN_CHAT_ID = process.env.VIPBOT_ADMIN_CHAT_ID;
const VIP_GROUP_ID = process.env.VIP_GROUP_ID;

function esc(text: string): string {
  return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

const PLANS: Record<string, { label: string; price: string; days: number }> = {
  "30days":  { label: "VIP 30 Days", price: "$14.99", days: 30 },
  "30-days": { label: "VIP 30 Days", price: "$14.99", days: 30 },
  "60days":  { label: "VIP 60 Days", price: "$24.99", days: 60 },
  "60-days": { label: "VIP 60 Days", price: "$24.99", days: 60 },
};

const PAYMENT_METHODS: Record<string, { label: string; emoji: string; details: string }> = {
  paypal:       { label: "PayPal",            emoji: "💳", details: "Send to: *zakpubgskin@paypal.com*\nNote: VIP Payment" },
  binance:      { label: "Binance Pay",       emoji: "🟡", details: "Binance UID: *zakarya_op*\nNetwork: BNB Smart Chain" },
  binance_gift: { label: "Binance Gift Card", emoji: "🎁", details: "Send the gift card code directly in chat after payment." },
  usdt:         { label: "USDT TRC20",        emoji: "💚", details: "Wallet: *TRC20 wallet address here*\nNetwork: TRC20 only" },
  easypaisa:    { label: "Easypaisa",         emoji: "🟢", details: "Account: *03192530306*\nName: *Zakarya*" },
  jazzcash:     { label: "JazzCash",          emoji: "🔴", details: "Account: *03192530306*\nName: *Zakarya*" },
  meezan:       { label: "Meezan Bank",       emoji: "🏦", details: "IBAN: *PK00MEZN0000000000000000*\nName: *Zakarya*" },
  nayapay:      { label: "NayaPay",           emoji: "🔵", details: "ID: *03192530306*\nName: *Zakarya*" },
  upi:          { label: "UPI",               emoji: "🇮🇳", details: "UPI ID: *zakarya@bank*" },
  paytm:        { label: "Paytm",             emoji: "💙", details: "Paytm: *+91-XXXXXXXXXX*\nName: *Zakarya*" },
  bkash:        { label: "bKash",             emoji: "🇧🇩", details: "bKash: *+880-XXXXXXXXXX*\nSend Money (not payment)" },
  nagad:        { label: "Nagad",             emoji: "🟠", details: "Nagad: *+880-XXXXXXXXXX*" },
  esewa:        { label: "eSewa",             emoji: "🇳🇵", details: "eSewa ID: *9800000000*" },
};

type UserStep = "idle" | "choosing_plan" | "choosing_payment" | "awaiting_screenshot" | "awaiting_gift_code" | "admin_send_link_id" | "admin_remove_id";

type UserState = {
  step: UserStep;
  plan?: string;
  paymentMethod?: string;
};

const userStates = new Map<string, UserState>();
let pollingOffset = 0;
let pollingActive = false;

// ─── API helpers ─────────────────────────────────────────────────────────────

async function apiCall(method: string, body: Record<string, any>): Promise<any> {
  if (!BOT_TOKEN) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!data.ok) {
      console.error(`[VIPBot] ${method} failed:`, JSON.stringify(data));
      return null;
    }
    return data.result;
  } catch (err) {
    console.error(`[VIPBot] ${method} error:`, err);
    return null;
  }
}

async function sendMsg(chatId: string | number, text: string, extra: Record<string, any> = {}): Promise<any> {
  return apiCall("sendMessage", { chat_id: chatId, text, parse_mode: "Markdown", ...extra });
}

async function editMsg(chatId: string | number, messageId: number, text: string, extra: Record<string, any> = {}) {
  return apiCall("editMessageText", { chat_id: chatId, message_id: messageId, text, parse_mode: "Markdown", ...extra });
}

async function answerCb(callbackQueryId: string, text?: string) {
  return apiCall("answerCallbackQuery", { callback_query_id: callbackQueryId, text: text || "" });
}

function isAdmin(chatId: string): boolean {
  return !!ADMIN_CHAT_ID && chatId === ADMIN_CHAT_ID;
}

// ─── Group invite ─────────────────────────────────────────────────────────────

async function generateGroupInvite(userId: string): Promise<string | null> {
  if (!VIP_GROUP_ID) return null;
  const expireDate = Math.floor(Date.now() / 1000) + 86400; // 24h
  const result = await apiCall("createChatInviteLink", {
    chat_id: VIP_GROUP_ID,
    member_limit: 1,
    expire_date: expireDate,
    name: `VIP-${userId}`,
  });
  return result?.invite_link || null;
}

async function removeFromGroup(userId: string): Promise<boolean> {
  if (!VIP_GROUP_ID) return false;
  const result = await apiCall("banChatMember", {
    chat_id: VIP_GROUP_ID,
    user_id: parseInt(userId),
    revoke_messages: false,
  });
  if (result !== null) {
    await apiCall("unbanChatMember", { chat_id: VIP_GROUP_ID, user_id: parseInt(userId) });
    return true;
  }
  return false;
}

// ─── Keyboards ────────────────────────────────────────────────────────────────

function planKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "🥈 30 Days — $14.99", callback_data: "plan_30days" }],
      [{ text: "👑 60 Days — $24.99", callback_data: "plan_60days" }],
      [{ text: "❌ Cancel", callback_data: "cancel" }],
    ],
  };
}

function paymentKeyboard() {
  const rows: any[][] = [];
  const keys = Object.keys(PAYMENT_METHODS);
  for (let i = 0; i < keys.length; i += 2) {
    const row = [{ text: `${PAYMENT_METHODS[keys[i]].emoji} ${PAYMENT_METHODS[keys[i]].label}`, callback_data: `pay_${keys[i]}` }];
    if (keys[i + 1]) row.push({ text: `${PAYMENT_METHODS[keys[i + 1]].emoji} ${PAYMENT_METHODS[keys[i + 1]].label}`, callback_data: `pay_${keys[i + 1]}` });
    rows.push(row);
  }
  rows.push([{ text: "⬅️ Back", callback_data: "back_to_plans" }]);
  return { inline_keyboard: rows };
}

function adminMainKeyboard() {
  return {
    inline_keyboard: [
      [{ text: "✅ VIP Users",     callback_data: "admin_vip_list_0"  }, { text: "⏳ Pending",       callback_data: "admin_pending_0"   }],
      [{ text: "❌ Rejected Users", callback_data: "admin_rejected_0" }, { text: "⏰ Expired Users",  callback_data: "admin_expired_0"   }],
      [{ text: "📤 Send Link",      callback_data: "admin_sendlink"   }, { text: "🗑 Remove User",    callback_data: "admin_remove"      }],
      [{ text: "📊 Stats",          callback_data: "admin_stats"      }],
    ],
  };
}

// ─── User bot flows ───────────────────────────────────────────────────────────

async function handleStart(chatId: string, name: string, payload?: string) {
  userStates.set(chatId, { step: "idle" });

  // VIP deep link: /start vip_TELEGRAMID  — auto-deliver the invite link
  if (payload && payload.startsWith("vip_")) {
    const targetId = payload.replace("vip_", "");
    // targetId may be numeric ID or username (without @)
    const isNumeric = /^\d+$/.test(targetId);
    const [user] = isNumeric
      ? await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, targetId))
      : await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramUsername, targetId));

    if (user) {
      // Always ensure the real chatId is linked (in case of ID mismatch)
      if (targetId !== chatId) {
        await db.update(vipBotUsers).set({ telegramId: chatId }).where(eq(vipBotUsers.telegramId, targetId)).catch(() => {});
      }

      if (user.status === "active") {
        // Payment already approved — deliver invite link now
        const inviteLink = await generateGroupInvite(chatId);
        if (inviteLink) {
          await db.update(vipBotUsers).set({ inviteLink }).where(eq(vipBotUsers.telegramId, chatId)).catch(() => {});
          const plan = PLANS[user.plan || ""]?.label || user.plan || "VIP";
          const expiry = user.expiryDate ? new Date(user.expiryDate).toLocaleDateString("en-GB") : "-";
          await apiCall("sendMessage", {
            chat_id: chatId,
            parse_mode: "HTML",
            text:
              `🎉 <b>Welcome to ZakPubgSkin VIP, ${esc(name)}!</b>\n\n` +
              `✅ <b>Your VIP is Active</b>\n` +
              `📦 Plan: <b>${esc(plan)}</b>\n` +
              `📅 Valid Until: <b>${expiry}</b>\n\n` +
              `🔗 <b>Join Your Exclusive VIP Group:</b>\n${inviteLink}\n\n` +
              `⚠️ <b>Important:</b> This link is for you only.\n• Valid for 24 hours\n• 1 use only — do not share\n\n` +
              `🎮 <b>Enjoy your premium PUBG experience!</b>`,
          });
          await sendMsg(ADMIN_CHAT_ID!, `✅ VIP link auto-delivered to ${esc(name)} (\`${chatId}\`)\n🔗 ${inviteLink}`);
          return;
        }
      } else if (user.status === "pending") {
        // Payment still under review — tell user we have them registered
        await apiCall("sendMessage", {
          chat_id: chatId,
          parse_mode: "HTML",
          text:
            `✅ <b>You're all set, ${esc(name)}!</b>\n\n` +
            `⏳ Your payment is currently being reviewed.\n\n` +
            `Once approved, you'll receive your <b>VIP group invite link automatically</b> right here — no action needed from you.\n\n` +
            `📞 Questions? Contact @zakarya_op`,
        });
        return;
      }
    }
    // Payload didn't resolve — fall through to normal start
  }

  await sendMsg(chatId,
    `🎮 *Welcome to ZakVIPBot, ${name}!*\n\nGet instant VIP access to premium PUBG configs, aimbot settings & private community.\n\nUse the buttons below to get started:`,
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: "💎 Buy VIP", callback_data: "buy" }, { text: "📊 My Status", callback_data: "vip_status" }],
          [{ text: "📞 Support", url: "https://t.me/zakarya_op" }],
        ],
      },
    }
  );
}

async function handleBuy(chatId: string, messageId?: number) {
  userStates.set(chatId, { step: "choosing_plan" });
  const text =
    `💎 *Choose Your VIP Plan*\n\n` +
    `🥈 *30 Days — $14.99*\n• Aimbot 30°–360°\n• CrossHair & Recoil\n• iPad View\n• 24/7 Support\n\n` +
    `👑 *60 Days — $24.99*\n• Everything in 30 Days\n• Player Speed\n• Magic Bullet\n• High Damage\n• Every 3 Days Update\n• Full Season Access`;
  if (messageId) {
    await editMsg(chatId, messageId, text, { reply_markup: planKeyboard() });
  } else {
    await sendMsg(chatId, text, { reply_markup: planKeyboard() });
  }
}

async function handleVipStatus(chatId: string, username?: string, name?: string) {
  const [user] = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, chatId));
  if (!user || user.status === "pending") {
    await sendMsg(chatId,
      `📊 *Your VIP Status*\n\n❌ No active VIP found.\n\nUse /buy to get VIP access now!`,
      { reply_markup: { inline_keyboard: [[{ text: "💎 Buy VIP", callback_data: "buy" }]] } }
    );
    return;
  }
  if (user.status === "active" && user.expiryDate) {
    const daysLeft = Math.max(0, Math.ceil((new Date(user.expiryDate).getTime() - Date.now()) / 86400000));
    const expiry = new Date(user.expiryDate).toLocaleDateString("en-GB");
    await sendMsg(chatId,
      `📊 *Your VIP Status*\n\n✅ *ACTIVE*\n📦 Plan: ${PLANS[user.plan || "30days"]?.label || user.plan}\n📅 Expires: ${expiry}\n⏳ Days Left: ${daysLeft}\n\n${daysLeft <= 5 ? "⚠️ Renew soon!" : "🎮 Enjoy your VIP!"}`,
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔗 Get New Invite Link", callback_data: "request_link" }],
            [{ text: "🔄 Renew VIP", callback_data: "buy" }],
          ],
        },
      }
    );
    return;
  }
  if (user.status === "rejected") {
    await sendMsg(chatId,
      `📊 *Your VIP Status*\n\n❌ Your last payment was *rejected*.\n\nPlease try again with a valid payment screenshot.`,
      { reply_markup: { inline_keyboard: [[{ text: "💎 Buy Again", callback_data: "buy" }]] } }
    );
    return;
  }
  if (user.status === "expired") {
    await sendMsg(chatId,
      `📊 *Your VIP Status*\n\n⏰ Your VIP has *expired*.\n\nRenew now to regain access!`,
      { reply_markup: { inline_keyboard: [[{ text: "🔄 Renew VIP", callback_data: "buy" }]] } }
    );
  }
}

async function handlePlanSelected(chatId: string, plan: string, cbId: string, messageId: number) {
  await answerCb(cbId);
  userStates.set(chatId, { step: "choosing_payment", plan });
  const planInfo = PLANS[plan];
  await editMsg(chatId, messageId,
    `✅ *Plan Selected: ${planInfo.label} (${planInfo.price})*\n\n💳 *Choose Payment Method:*`,
    { reply_markup: paymentKeyboard() }
  );
}

async function handlePaymentSelected(chatId: string, paymentKey: string, cbId: string, messageId: number, state: UserState) {
  await answerCb(cbId);
  const pm = PAYMENT_METHODS[paymentKey];
  if (!pm) return;
  const planInfo = PLANS[state.plan || "30days"];

  if (paymentKey === "binance_gift") {
    userStates.set(chatId, { ...state, step: "awaiting_gift_code", paymentMethod: paymentKey });
    await editMsg(chatId, messageId,
      `🎁 *Binance Gift Card — ${planInfo.label} (${planInfo.price})*\n\nPlease send your Binance Gift Card code directly in this chat.\n\n_Your code will be verified by admin._`,
      { reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_to_payment" }]] } }
    );
    return;
  }

  userStates.set(chatId, { ...state, step: "awaiting_screenshot", paymentMethod: paymentKey });
  await editMsg(chatId, messageId,
    `💳 *${pm.emoji} ${pm.label} — ${planInfo.label} (${planInfo.price})*\n\n*Payment Details:*\n${pm.details}\n\n*Amount:* ${planInfo.price}\n\n📸 *Send your payment screenshot* after completing the payment.\n\n_Admin will verify and activate your VIP instantly._`,
    { reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_to_payment" }]] } }
  );
}

async function handleScreenshot(chatId: string, username: string | undefined, name: string, fileId: string, state: UserState) {
  const plan = state.plan || "30days";
  const paymentMethod = state.paymentMethod || "unknown";
  const existing = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, chatId));
  if (existing.length > 0) {
    await db.update(vipBotUsers).set({ plan, paymentMethod, screenshotFileId: fileId, status: "pending", telegramUsername: username, telegramName: name }).where(eq(vipBotUsers.telegramId, chatId));
  } else {
    await db.insert(vipBotUsers).values({ telegramId: chatId, telegramUsername: username, telegramName: name, plan, paymentMethod, screenshotFileId: fileId, status: "pending" });
  }
  userStates.set(chatId, { step: "idle" });

  await sendMsg(chatId,
    `✅ *Screenshot received!*\n\n📦 Plan: ${PLANS[plan].label}\n💳 Method: ${PAYMENT_METHODS[paymentMethod]?.label || paymentMethod}\n\n⏳ Admin is verifying your payment. You'll be notified within minutes.\n\n_Do not send multiple screenshots._`
  );

  if (ADMIN_CHAT_ID) {
    const pmLabel = PAYMENT_METHODS[paymentMethod]?.label || paymentMethod;
    const userLink = username ? `@${username}` : name;
    const caption =
      `💰 *NEW PAYMENT REQUEST*\n\n` +
      `👤 User: ${userLink}\n` +
      `🆔 ID: \`${chatId}\`\n` +
      `📦 Plan: ${PLANS[plan].label}\n` +
      `💳 Method: ${pmLabel}\n` +
      `🗓 Date: ${new Date().toLocaleString("en-GB")}`;
    await apiCall("sendPhoto", {
      chat_id: ADMIN_CHAT_ID,
      photo: fileId,
      caption,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[
          { text: "✅ Approve", callback_data: `vipapprove_${chatId}` },
          { text: "❌ Reject",  callback_data: `vipreject_${chatId}`  },
        ]],
      },
    });
  }
}

async function handleGiftCode(chatId: string, username: string | undefined, name: string, code: string, state: UserState) {
  const plan = state.plan || "30days";
  const existing = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, chatId));
  if (existing.length > 0) {
    await db.update(vipBotUsers).set({ plan, paymentMethod: "binance_gift", screenshotFileId: code, status: "pending", telegramUsername: username, telegramName: name }).where(eq(vipBotUsers.telegramId, chatId));
  } else {
    await db.insert(vipBotUsers).values({ telegramId: chatId, telegramUsername: username, telegramName: name, plan, paymentMethod: "binance_gift", screenshotFileId: code, status: "pending" });
  }
  userStates.set(chatId, { step: "idle" });
  await sendMsg(chatId, `🎁 *Gift card code received!*\n\nCode: \`${code}\`\n\n⏳ Admin will verify and activate your VIP shortly.`);

  if (ADMIN_CHAT_ID) {
    const userLink = username ? `@${username}` : name;
    await sendMsg(ADMIN_CHAT_ID,
      `🎁 *BINANCE GIFT CARD PAYMENT*\n\n👤 User: ${userLink}\n🆔 ID: \`${chatId}\`\n📦 Plan: ${PLANS[plan].label}\n🎁 Code: \`${code}\``,
      {
        reply_markup: {
          inline_keyboard: [[
            { text: "✅ Approve", callback_data: `vipapprove_${chatId}` },
            { text: "❌ Reject",  callback_data: `vipreject_${chatId}`  },
          ]],
        },
      }
    );
  }
}

// ─── Approve / Reject ─────────────────────────────────────────────────────────

async function handleApprove(adminChatId: string, targetUserId: string, cbId: string, messageId: number) {
  await answerCb(cbId, "Processing...");
  const [user] = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, targetUserId));
  if (!user) { await sendMsg(adminChatId, "❌ User not found."); return; }

  const plan = user.plan || "30days";
  const planInfo = PLANS[plan] || PLANS["30days"];
  const expiryDate = new Date(Date.now() + planInfo.days * 86400000);
  const inviteLink = await generateGroupInvite(targetUserId);

  await db.update(vipBotUsers).set({
    status: "active",
    expiryDate,
    inviteLink: inviteLink || undefined,
    invitedToGroup: !!inviteLink,
    approvedAt: new Date(),
  }).where(eq(vipBotUsers.telegramId, targetUserId));

  // Also approve in the members table
  await db.update(members).set({
    status: "active",
    expiryDate,
  }).where(eq(members.telegramId, targetUserId)).catch(() => {});

  const expStr = expiryDate.toLocaleDateString("en-GB");

  const userRef = user.telegramUsername ? `@${user.telegramUsername}` : user.telegramName || targetUserId;

  let notified = false;
  if (inviteLink) {
    const sent = await apiCall("sendMessage", {
      chat_id: targetUserId,
      parse_mode: "HTML",
      text:
        `🎉 <b>Welcome to ZakPubgSkin VIP!</b>\n\n` +
        `✅ <b>Your VIP is Active</b>\n` +
        `📦 Plan: <b>${planInfo.label}</b>\n` +
        `📅 Valid Until: <b>${expStr}</b>\n\n` +
        `🔗 <b>Join Your Exclusive VIP Group:</b>\n${inviteLink}\n\n` +
        `⚠️ <b>Important:</b> This link is for you only.\n• Valid for 24 hours\n• 1 use only — do not share\n\n` +
        `🎮 <b>Enjoy your premium PUBG experience!</b>`,
    });
    notified = !!sent;
  }

  if (!notified) {
    const cleanId = targetUserId.replace(/^@/, "");
    const deepLink = `https://t.me/Zaksite_bot?start=vip_${cleanId}`;
    await sendMsg(adminChatId,
      `⚠️ *${userRef}* hasn't started the bot yet.\n\n` +
      `📲 *Send them this magic link:*\n${deepLink}\n\n` +
      `When they tap it and press START, the bot will *automatically send their VIP invite link*.\n\n` +
      (inviteLink ? `🔗 Or share the invite link directly:\n${inviteLink}` : `❌ Could not generate invite link — check VIP group bot permissions.`)
    );
  }

  const doneText = `✅ APPROVED — ${userRef}\n📦 ${planInfo.label} until ${expStr}`;
  const edited = await apiCall("editMessageCaption", {
    chat_id: adminChatId, message_id: messageId,
    caption: doneText, reply_markup: { inline_keyboard: [] },
  });
  if (!edited) {
    await apiCall("editMessageText", {
      chat_id: adminChatId, message_id: messageId,
      text: doneText, reply_markup: { inline_keyboard: [] },
    });
  }

  await sendMsg(adminChatId, `✅ *Approved:* ${userRef} — ${planInfo.label} until *${expStr}*\n🔗 Link: ${inviteLink || "none (group not set)"}`);
}

async function handleReject(adminChatId: string, targetUserId: string, cbId: string, messageId: number) {
  await answerCb(cbId, "Rejected.");
  await db.update(vipBotUsers).set({ status: "rejected" }).where(eq(vipBotUsers.telegramId, targetUserId));
  const [user] = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, targetUserId));
  const userRef = user?.telegramUsername ? `@${user.telegramUsername}` : user?.telegramName || targetUserId;

  await sendMsg(targetUserId,
    `❌ *Payment Rejected*\n\nYour payment screenshot could not be verified.\n\nPlease try again with a clear screenshot or contact @zakarya_op for help.`,
    { reply_markup: { inline_keyboard: [[{ text: "🔄 Try Again", callback_data: "buy" }]] } }
  );

  const rejectText = `❌ REJECTED — ${userRef}`;
  const rejEdited = await apiCall("editMessageCaption", {
    chat_id: adminChatId, message_id: messageId,
    caption: rejectText, reply_markup: { inline_keyboard: [] },
  });
  if (!rejEdited) {
    await apiCall("editMessageText", {
      chat_id: adminChatId, message_id: messageId,
      text: rejectText, reply_markup: { inline_keyboard: [] },
    });
  }

  await sendMsg(adminChatId, `❌ Rejected: ${userRef}`);
}

// ─── Admin panel ──────────────────────────────────────────────────────────────

async function handleAdminMenu(chatId: string, messageId?: number) {
  const allUsers = await db.select().from(vipBotUsers);
  const active   = allUsers.filter(u => u.status === "active").length;
  const pending  = allUsers.filter(u => u.status === "pending").length;
  const rejected = allUsers.filter(u => u.status === "rejected").length;
  const expired  = allUsers.filter(u => u.status === "expired").length;

  const text =
    `🛡 *Admin Panel — ZakVIPBot*\n\n` +
    `📊 *Overview:*\n` +
    `✅ Active VIP: *${active}*\n` +
    `⏳ Pending: *${pending}*\n` +
    `❌ Rejected: *${rejected}*\n` +
    `⏰ Expired: *${expired}*\n` +
    `👥 Total: *${allUsers.length}*\n\n` +
    `Select an action below:`;

  if (messageId) {
    await editMsg(chatId, messageId, text, { reply_markup: adminMainKeyboard() });
  } else {
    await sendMsg(chatId, text, { reply_markup: adminMainKeyboard() });
  }
}

async function handleAdminStats(chatId: string, cbId: string, messageId: number) {
  await answerCb(cbId);
  const allUsers = await db.select().from(vipBotUsers).orderBy(desc(vipBotUsers.createdAt));
  const active   = allUsers.filter(u => u.status === "active");
  const pending  = allUsers.filter(u => u.status === "pending");
  const rejected = allUsers.filter(u => u.status === "rejected");
  const expired  = allUsers.filter(u => u.status === "expired");

  const expiringToday = active.filter(u => {
    if (!u.expiryDate) return false;
    const daysLeft = Math.ceil((new Date(u.expiryDate).getTime() - Date.now()) / 86400000);
    return daysLeft <= 1;
  });

  const expiringSoon = active.filter(u => {
    if (!u.expiryDate) return false;
    const daysLeft = Math.ceil((new Date(u.expiryDate).getTime() - Date.now()) / 86400000);
    return daysLeft <= 5 && daysLeft > 1;
  });

  const text =
    `📊 *Detailed Statistics*\n\n` +
    `👥 Total Users: *${allUsers.length}*\n` +
    `✅ Active VIP: *${active.length}*\n` +
    `⏳ Pending Review: *${pending.length}*\n` +
    `❌ Rejected: *${rejected.length}*\n` +
    `⏰ Expired: *${expired.length}*\n\n` +
    `⚠️ Expiring Today: *${expiringToday.length}*\n` +
    `🔔 Expiring in 5 Days: *${expiringSoon.length}*`;

  await editMsg(chatId, messageId, text, {
    reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "admin_menu" }]] },
  });
}

async function handleAdminUserList(chatId: string, cbId: string, messageId: number, status: string, page: number) {
  await answerCb(cbId);
  const PAGE_SIZE = 3;
  const allUsers = await db.select().from(vipBotUsers)
    .where(eq(vipBotUsers.status, status))
    .orderBy(desc(vipBotUsers.createdAt));

  const total = allUsers.length;
  const start = page * PAGE_SIZE;
  const users = allUsers.slice(start, start + PAGE_SIZE);

  const statusEmoji: Record<string, string> = { active: "✅", pending: "⏳", rejected: "❌", expired: "⏰" };
  const statusLabel: Record<string, string> = { active: "VIP Users", pending: "Pending Payments", rejected: "Rejected", expired: "Expired" };
  const cbPrefix: Record<string, string> = { active: "admin_vip_list_", pending: "admin_pending_", rejected: "admin_rejected_", expired: "admin_expired_" };

  if (users.length === 0) {
    await editMsg(chatId, messageId, `${statusEmoji[status]} *${statusLabel[status]}*\n\nNo users found.`, {
      reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "admin_menu" }]] },
    });
    return;
  }

  let text = `${statusEmoji[status]} *${statusLabel[status]}* (${start + 1}–${Math.min(start + PAGE_SIZE, total)} of ${total})\n\n`;

  const userActionRows: any[][] = [];

  const telegramIds = users.map(u => u.telegramId);
  const memberRows = status === "pending"
    ? await db.select().from(members).where(eq(members.telegramId, telegramIds[0] ?? "")).catch(() => [])
    : [];
  const memberCountryMap: Record<string, string> = {};
  for (const m of memberRows) memberCountryMap[m.telegramId] = m.country || "—";
  if (status === "pending" && telegramIds.length > 1) {
    for (const tid of telegramIds.slice(1)) {
      const rows = await db.select().from(members).where(eq(members.telegramId, tid)).catch(() => []);
      if (rows[0]) memberCountryMap[rows[0].telegramId] = rows[0].country || "—";
    }
  }

  for (const u of users) {
    const name = u.telegramUsername ? `@${u.telegramUsername}` : u.telegramName || `ID:${u.telegramId}`;
    const plan = PLANS[u.plan || ""]?.label || u.plan || "—";
    const expiry = u.expiryDate ? new Date(u.expiryDate).toLocaleDateString("en-GB") : "—";
    const daysLeft = u.expiryDate && status === "active"
      ? Math.max(0, Math.ceil((new Date(u.expiryDate).getTime() - Date.now()) / 86400000))
      : null;
    const country = memberCountryMap[u.telegramId] || "—";

    text += `👤 *${name}*\n`;
    text += `🆔 \`${u.telegramId}\`\n`;
    text += `📦 ${plan}\n`;
    if (status === "active")   text += `📅 Expires: ${expiry} (${daysLeft}d left)\n`;
    if (status === "pending") {
      text += `💳 ${PAYMENT_METHODS[u.paymentMethod || ""]?.label || u.paymentMethod || "—"}\n`;
      if (country !== "—") text += `🌍 ${country}\n`;
    }
    if (status === "rejected") text += `❌ Rejected\n`;
    if (status === "expired")  text += `📅 Expired: ${expiry}\n`;
    text += `\n`;

    if (status === "pending") {
      const pendingRow: any[] = [
        { text: `✅ Approve`, callback_data: `vipapprove_${u.telegramId}` },
        { text: `❌ Reject`,  callback_data: `vipreject_${u.telegramId}`  },
      ];
      userActionRows.push(pendingRow);

      if (u.screenshotFileId && u.screenshotFileId.startsWith("/uploads/")) {
        const domain = process.env.REPLIT_DEV_DOMAIN || process.env.REPLIT_DOMAINS?.split(",")[0] || "";
        const screenshotUrl = domain ? `https://${domain}${u.screenshotFileId}` : null;
        if (screenshotUrl) {
          userActionRows.push([{ text: `📸 View Screenshot`, url: screenshotUrl }]);
        }
      }
    }
    if (status === "active") {
      userActionRows.push([
        { text: `📤 Send Link to ${name}`, callback_data: `admin_quicklink_${u.telegramId}` },
        { text: `🗑 Remove`,               callback_data: `admin_quickremove_${u.telegramId}` },
      ]);
    }
  }

  const navButtons: any[] = [];
  if (page > 0) navButtons.push({ text: "⬅️ Prev", callback_data: `${cbPrefix[status]}${page - 1}` });
  if (start + PAGE_SIZE < total) navButtons.push({ text: "Next ➡️", callback_data: `${cbPrefix[status]}${page + 1}` });

  const keyboard: any[][] = [...userActionRows];
  if (navButtons.length) keyboard.push(navButtons);

  if (status === "active") keyboard.push([{ text: "📤 Send Link by Username", callback_data: "admin_sendlink" }]);
  keyboard.push([{ text: "⬅️ Back to Menu", callback_data: "admin_menu" }]);

  await editMsg(chatId, messageId, text, { reply_markup: { inline_keyboard: keyboard } });
}

async function resolveUser(input: string) {
  const clean = input.replace(/^@/, "").trim();

  // 1. Search vipBotUsers by telegramId
  const byId = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, clean));
  if (byId.length > 0) return byId[0];

  // 2. Search vipBotUsers by stored username
  const byUsername = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramUsername, clean));
  if (byUsername.length > 0) return byUsername[0];

  // 3. Try resolving via Telegram getChat (works for public usernames)
  try {
    const chatId = input.startsWith("@") ? input : (isNaN(Number(clean)) ? `@${clean}` : clean);
    const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getChat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId }),
    });
    const data = await res.json() as any;
    if (data.ok && data.result?.id) {
      const resolvedId = String(data.result.id);
      const resolvedUsername = data.result.username || null;
      const resolvedName = [data.result.first_name, data.result.last_name].filter(Boolean).join(" ") || null;

      // 4. Search vipBotUsers by resolved Telegram ID
      const byResolvedId = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, resolvedId));
      if (byResolvedId.length > 0) {
        // Update username if missing
        if (!byResolvedId[0].telegramUsername && resolvedUsername) {
          await db.update(vipBotUsers).set({ telegramUsername: resolvedUsername, telegramName: resolvedName }).where(eq(vipBotUsers.telegramId, resolvedId));
        }
        return byResolvedId[0];
      }

      // 5. Fallback: check members table
      const memberRows = await db.select().from(members).where(eq(members.telegramId, resolvedId));
      if (memberRows.length > 0) {
        const m = memberRows[0];
        // Upsert into vipBotUsers so they appear properly
        await db.insert(vipBotUsers).values({
          telegramId: resolvedId,
          telegramUsername: resolvedUsername,
          telegramName: resolvedName,
          plan: m.plan,
          paymentMethod: m.paymentMethod,
          status: m.status === "active" ? "active" : "pending",
          expiryDate: m.expiryDate,
        }).onConflictDoUpdate({
          target: vipBotUsers.telegramId,
          set: { telegramUsername: resolvedUsername, telegramName: resolvedName },
        });
        const [updated] = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, resolvedId));
        return updated;
      }
    }
  } catch (err) {
    console.error("[VIPBot] resolveUser getChat error:", err);
  }

  return null;
}

async function sendWelcomeWithLink(targetUserId: string, user: any, inviteLink: string) {
  const expiry = user.expiryDate ? new Date(user.expiryDate).toLocaleDateString("en-GB") : "-";
  const plan = PLANS[user.plan || ""]?.label || user.plan || "VIP";
  const rawName = user.telegramName || (user.telegramUsername ? `@${user.telegramUsername}` : "Member");
  const userName = rawName.replace(/[_*[\]()~`>#+=|{}.!-]/g, "\\$&");

  await apiCall("sendMessage", {
    chat_id: targetUserId,
    parse_mode: "HTML",
    text:
      `🎉 <b>Welcome to ZakPubgSkin VIP, ${userName}!</b>\n\n` +
      `- - - - - - - - - - - - - - - - -\n` +
      `✅ <b>Your VIP is Active</b>\n` +
      `📦 Plan: <b>${plan}</b>\n` +
      `📅 Valid Until: <b>${expiry}</b>\n` +
      `- - - - - - - - - - - - - - - - -\n\n` +
      `🔗 <b>Join Your Exclusive VIP Group:</b>\n${inviteLink}\n\n` +
      `⚠️ <b>Important:</b> This link is for you only.\n` +
      `• Valid for 24 hours\n` +
      `• 1 use only — do not share\n\n` +
      `<i>Use /vip anytime to check your status.</i>\n\n` +
      `🎮 <b>Enjoy your premium PUBG experience!</b>`,
  });
}

async function handleAdminSendLink(chatId: string, input: string) {
  const user = await resolveUser(input);
  if (!user) {
    await sendMsg(chatId, `❌ No user found with ID or username *${input}*.\n\nTry the exact Telegram ID or @username.`);
    return;
  }
  if (user.status !== "active") {
    const ref = user.telegramUsername ? `@${user.telegramUsername}` : user.telegramName || user.telegramId;
    await sendMsg(chatId, `⚠️ *${ref}* is not active (status: *${user.status}*).\n\nCannot send VIP link to inactive users.`);
    return;
  }

  const inviteLink = await generateGroupInvite(user.telegramId);
  if (!inviteLink) {
    await sendMsg(chatId, `❌ Failed to generate invite link. Check VIP_GROUP_ID and bot permissions.`);
    return;
  }

  await db.update(vipBotUsers).set({ inviteLink }).where(eq(vipBotUsers.telegramId, user.telegramId));

  const userRef = user.telegramUsername ? `@${user.telegramUsername}` : user.telegramName || user.telegramId;

  // Try sending welcome message — may fail if user never started the bot
  const sendResult = await apiCall("sendMessage", {
    chat_id: user.telegramId,
    parse_mode: "HTML",
    text:
      `🎉 <b>Welcome to ZakPubgSkin VIP!</b>\n\n` +
      `✅ <b>Your VIP is Active</b>\n` +
      `📦 Plan: <b>${PLANS[user.plan || ""]?.label || user.plan || "VIP"}</b>\n` +
      `📅 Valid Until: <b>${user.expiryDate ? new Date(user.expiryDate).toLocaleDateString("en-GB") : "-"}</b>\n\n` +
      `🔗 <b>Join Your Exclusive VIP Group:</b>\n${inviteLink}\n\n` +
      `⚠️ <b>Important:</b> This link is for you only.\n• Valid for 24 hours\n• 1 use only — do not share\n\n` +
      `🎮 <b>Enjoy your premium PUBG experience!</b>`,
  });

  const cleanUserId = user.telegramId.replace(/^@/, "");
  const deepLink = `https://t.me/Zaksite_bot?start=vip_${cleanUserId}`;

  if (sendResult) {
    await sendMsg(chatId, `✅ Welcome message + invite link sent to *${userRef}*\n🔗 ${inviteLink}`);
  } else {
    await sendMsg(chatId,
      `⚠️ *${userRef}* hasn't started the bot yet.\n\n` +
      `📲 *Send them this magic link:*\n${deepLink}\n\n` +
      `When they tap it and press START, the bot will *automatically send their VIP invite link*.\n\n` +
      `🔗 Or share the invite link directly:\n${inviteLink}`
    );
  }
  userStates.set(chatId, { step: "idle" });
}

async function handleAdminRemoveUser(chatId: string, targetUserId: string) {
  const user = await resolveUser(targetUserId);
  if (!user) {
    await sendMsg(chatId, `❌ No user found with ID or username *${targetUserId}*.`);
    return;
  }

  const uid = user.telegramId;
  const removed = await removeFromGroup(uid);
  await db.update(vipBotUsers).set({ status: "expired", invitedToGroup: false }).where(eq(vipBotUsers.telegramId, uid));

  const userRef = user.telegramUsername ? `@${user.telegramUsername}` : user.telegramName || uid;

  await sendMsg(uid,
    `⛔ *VIP Access Removed*\n\nYour VIP membership has been terminated by the admin.\n\nContact @zakarya_op for help or to renew.`,
    { reply_markup: { inline_keyboard: [[{ text: "🔄 Renew VIP", callback_data: "buy" }]] } }
  );

  await sendMsg(chatId,
    `✅ *User removed:* ${userRef}\n` +
    `🗑 Kicked from group: ${removed ? "Yes" : "Could not kick (may not be in group)"}\n` +
    `📊 Status set to: *expired*`
  );
  userStates.set(chatId, { step: "idle" });
}

// ─── Update router ────────────────────────────────────────────────────────────

async function processUpdate(update: any) {
  if (update.callback_query) {
    const cb = update.callback_query;
    const chatId = String(cb.from.id);
    const data = cb.data as string;
    const messageId = cb.message?.message_id;
    const state = userStates.get(chatId) || { step: "idle" as UserStep };

    // ── Admin callbacks ──
    if (isAdmin(chatId)) {
      if (data === "admin_menu") {
        await answerCb(cb.id);
        await handleAdminMenu(chatId, messageId);
        return;
      }
      if (data === "admin_stats") {
        await handleAdminStats(chatId, cb.id, messageId);
        return;
      }
      if (data.startsWith("admin_vip_list_")) {
        const page = parseInt(data.replace("admin_vip_list_", "")) || 0;
        await handleAdminUserList(chatId, cb.id, messageId, "active", page);
        return;
      }
      if (data.startsWith("admin_pending_")) {
        const page = parseInt(data.replace("admin_pending_", "")) || 0;
        await handleAdminUserList(chatId, cb.id, messageId, "pending", page);
        return;
      }
      if (data.startsWith("admin_rejected_")) {
        const page = parseInt(data.replace("admin_rejected_", "")) || 0;
        await handleAdminUserList(chatId, cb.id, messageId, "rejected", page);
        return;
      }
      if (data.startsWith("admin_expired_")) {
        const page = parseInt(data.replace("admin_expired_", "")) || 0;
        await handleAdminUserList(chatId, cb.id, messageId, "expired", page);
        return;
      }
      if (data === "admin_sendlink") {
        await answerCb(cb.id);
        userStates.set(chatId, { step: "admin_send_link_id" });
        await editMsg(chatId, messageId,
          `📤 *Send VIP Group Link*\n\nReply with the user's *Telegram ID* or *@username*.\n\nThe bot will automatically send them a welcome message + private invite link.\n\n_Examples:_\n• \`123456789\`\n• \`@username\``,
          { reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "admin_menu" }]] } }
        );
        return;
      }
      if (data === "admin_remove") {
        await answerCb(cb.id);
        userStates.set(chatId, { step: "admin_remove_id" });
        await editMsg(chatId, messageId,
          `🗑 *Remove User from VIP*\n\nReply with the Telegram user ID or @username to remove.\n\n⚠️ This will kick them from the group and mark their VIP as expired.\n\n_Examples:_\n• \`123456789\`\n• \`@username\``,
          { reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "admin_menu" }]] } }
        );
        return;
      }
      if (data.startsWith("admin_quicklink_")) {
        await answerCb(cb.id, "Generating link...");
        const targetId = data.replace("admin_quicklink_", "");
        await handleAdminSendLink(chatId, targetId);
        return;
      }
      if (data.startsWith("admin_quickremove_")) {
        await answerCb(cb.id, "Removing...");
        const targetId = data.replace("admin_quickremove_", "");
        await handleAdminRemoveUser(chatId, targetId);
        return;
      }
    }

    // ── Approve / Reject (admin) ──
    if (data.startsWith("vipapprove_") && isAdmin(chatId)) {
      await handleApprove(chatId, data.replace("vipapprove_", ""), cb.id, messageId);
      return;
    }
    if (data.startsWith("vipreject_") && isAdmin(chatId)) {
      await handleReject(chatId, data.replace("vipreject_", ""), cb.id, messageId);
      return;
    }

    // ── User request new link ──
    if (data === "request_link") {
      await answerCb(cb.id, "Generating link...");
      const [user] = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, chatId));
      if (user?.status === "active") {
        const link = await generateGroupInvite(chatId);
        if (link) {
          await db.update(vipBotUsers).set({ inviteLink: link }).where(eq(vipBotUsers.telegramId, chatId));
          await sendMsg(chatId, `🔗 *Your VIP Group Link:*\n\n${link}\n\n⚠️ Valid for 24 hours, 1 use only.`);
        } else {
          await sendMsg(chatId, `❌ Could not generate link. Contact @zakarya_op for help.`);
        }
      } else {
        await sendMsg(chatId, `❌ No active VIP found.`);
      }
      return;
    }

    // ── Standard user callbacks ──
    if (data === "buy" || data === "back_to_plans") {
      await handleBuy(chatId, messageId);
    } else if (data === "vip_status") {
      await answerCb(cb.id);
      await handleVipStatus(chatId, cb.from.username, cb.from.first_name);
    } else if (data === "cancel") {
      await answerCb(cb.id);
      userStates.set(chatId, { step: "idle" });
      await editMsg(chatId, messageId, "❌ Cancelled. Use /buy to start again.");
    } else if (data === "back_to_payment") {
      userStates.set(chatId, { ...state, step: "choosing_payment" });
      await editMsg(chatId, messageId, `💳 *Choose Payment Method:*`, { reply_markup: paymentKeyboard() });
      await answerCb(cb.id);
    } else if (data.startsWith("plan_")) {
      await handlePlanSelected(chatId, data.replace("plan_", ""), cb.id, messageId);
    } else if (data.startsWith("pay_")) {
      await handlePaymentSelected(chatId, data.replace("pay_", ""), cb.id, messageId, state);
    } else {
      await answerCb(cb.id);
    }
    return;
  }

  if (update.message) {
    const msg = update.message;
    const chatId = String(msg.chat.id);
    const name = msg.from?.first_name || "User";
    const username = msg.from?.username;
    const text = msg.text as string | undefined;
    const photo = msg.photo as any[] | undefined;
    const state = userStates.get(chatId) || { step: "idle" as UserStep };

    // ── Admin text-input flows ──
    if (isAdmin(chatId)) {
      if (state.step === "admin_send_link_id" && text && !text.startsWith("/")) {
        const targetId = text.trim();
        await handleAdminSendLink(chatId, targetId);
        await handleAdminMenu(chatId);
        return;
      }
      if (state.step === "admin_remove_id" && text && !text.startsWith("/")) {
        const targetId = text.trim();
        await handleAdminRemoveUser(chatId, targetId);
        await handleAdminMenu(chatId);
        return;
      }
    }

    // ── Commands ──
    if (text.startsWith("/start")) {
      const payload = text.split(" ")[1] || undefined;
      await handleStart(chatId, name, payload);
      return;
    }
    if (text === "/buy")   { await handleBuy(chatId); return; }
    if (text === "/vip")   { await handleVipStatus(chatId, username, name); return; }
    if (text === "/myid") {
      await sendMsg(chatId,
        `🆔 *Your Telegram Chat ID:*\n\n\`${chatId}\`\n\nTo become admin, set \`VIPBOT_ADMIN_CHAT_ID\` to this value in your Replit Secrets.`
      );
      return;
    }
    if (text === "/admin") {
      if (isAdmin(chatId)) {
        await handleAdminMenu(chatId);
      } else {
        await sendMsg(chatId,
          `🚫 *Admin access denied.*\n\nYour Chat ID: \`${chatId}\`\n\nIf you are the owner, set \`VIPBOT_ADMIN_CHAT_ID\` = \`${chatId}\` in Replit Secrets.`
        );
      }
      return;
    }

    // ── Admin helper commands ──
    if (isAdmin(chatId)) {
      if (text?.startsWith("/send ")) {
        const userId = text.replace("/send ", "").trim();
        await handleAdminSendLink(chatId, userId);
        return;
      }
      if (text?.startsWith("/remove ")) {
        const userId = text.replace("/remove ", "").trim();
        await handleAdminRemoveUser(chatId, userId);
        return;
      }
      if (text?.startsWith("/approve ")) {
        const userId = text.replace("/approve ", "").trim();
        const [user] = await db.select().from(vipBotUsers).where(eq(vipBotUsers.telegramId, userId));
        if (!user) { await sendMsg(chatId, `❌ User \`${userId}\` not found.`); return; }
        const plan = user.plan || "30days";
        const planInfo = PLANS[plan];
        const expiryDate = new Date(Date.now() + planInfo.days * 86400000);
        const inviteLink = await generateGroupInvite(userId);
        await db.update(vipBotUsers).set({ status: "active", expiryDate, inviteLink: inviteLink || undefined, invitedToGroup: !!inviteLink, approvedAt: new Date() }).where(eq(vipBotUsers.telegramId, userId));
        const expStr = expiryDate.toLocaleDateString("en-GB");
        const groupLine = inviteLink ? `\n\n🔗 *Join VIP Group:*\n${inviteLink}\n\n⚠️ 24h, 1 use.` : "";
        await sendMsg(userId, `🎉 *VIP ACTIVATED!*\n\n📦 Plan: *${planInfo.label}*\n📅 Expires: *${expStr}*${groupLine}\n\n_Use /vip to check status._`);
        const userRef = user.telegramUsername ? `@${user.telegramUsername}` : user.telegramName || userId;
        await sendMsg(chatId, `✅ Manually approved: ${userRef} — ${planInfo.label} until ${expStr}`);
        return;
      }
      if (text?.startsWith("/reject ")) {
        const userId = text.replace("/reject ", "").trim();
        await db.update(vipBotUsers).set({ status: "rejected" }).where(eq(vipBotUsers.telegramId, userId));
        await sendMsg(userId, `❌ *Payment Rejected*\n\nPlease resubmit with a clear screenshot or contact @zakarya_op.`, { reply_markup: { inline_keyboard: [[{ text: "🔄 Try Again", callback_data: "buy" }]] } });
        await sendMsg(chatId, `❌ Rejected user \`${userId}\`.`);
        return;
      }
    }

    // ── Screenshot handling ──
    if (state.step === "awaiting_screenshot" && photo && photo.length > 0) {
      await handleScreenshot(chatId, username, name, photo[photo.length - 1].file_id, state);
      return;
    }
    if (state.step === "awaiting_screenshot" && !photo) {
      await sendMsg(chatId, "📸 Please send a *screenshot* (image) of your payment, not text.");
      return;
    }
    if (state.step === "awaiting_gift_code" && text) {
      await handleGiftCode(chatId, username, name, text.trim(), state);
      return;
    }

    // ── Default ──
    if (!text?.startsWith("/")) {
      await sendMsg(chatId, `👋 Hi *${name}*! Use the buttons below:`, {
        reply_markup: {
          inline_keyboard: [
            [{ text: "💎 Buy VIP", callback_data: "buy" }, { text: "📊 My Status", callback_data: "vip_status" }],
            [{ text: "📞 Support", url: "https://t.me/zakarya_op" }],
          ],
        },
      });
    }
  }
}

// ─── Polling ──────────────────────────────────────────────────────────────────

async function pollUpdates() {
  if (!BOT_TOKEN) {
    console.warn("[VIPBot] VIPBOT_TOKEN not set — bot disabled.");
    return;
  }
  pollingActive = true;
  console.log("[VIPBot] Polling started.");

  while (pollingActive) {
    try {
      const result = await apiCall("getUpdates", {
        offset: pollingOffset,
        timeout: 25,
        allowed_updates: ["message", "callback_query"],
      });
      if (result && Array.isArray(result)) {
        for (const update of result) {
          pollingOffset = update.update_id + 1;
          processUpdate(update).catch(err => console.error("[VIPBot] processUpdate error:", err));
        }
      }
    } catch (err) {
      console.error("[VIPBot] Polling error:", err);
      await new Promise(r => setTimeout(r, 3000));
    }
  }
}

export async function sendOrderAlert(data: {
  telegramId: string;
  plan: string;
  country: string;
  paymentMethod: string;
  orderId: number;
  screenshotPath?: string;
  giftCardCode?: string;
}) {
  if (!ADMIN_CHAT_ID) return;

  const planLabel = PLANS[data.plan]?.label || (data.plan === "60-days" ? "VIP 60 Days" : "VIP 30 Days");
  const payLabel = PAYMENT_METHODS[data.paymentMethod]?.label || data.paymentMethod;

  const caption =
    `🔔 <b>NEW ORDER ALERT!</b>\n\n` +
    `👤 Telegram ID: <code>${esc(data.telegramId)}</code>\n` +
    `📦 Plan: <b>${esc(planLabel)}</b>\n` +
    `🌍 Country: ${esc(data.country)}\n` +
    `💳 Payment: ${esc(payLabel)}\n` +
    (data.giftCardCode ? `🎁 Gift Card: <code>${esc(data.giftCardCode)}</code>\n` : "") +
    `🆔 Order: #${data.orderId}\n\n` +
    `Tap ✅ Approve to send the VIP invite link automatically.`;

  const markup = {
    inline_keyboard: [[
      { text: "✅ Approve", callback_data: `vipapprove_${data.telegramId}` },
      { text: "❌ Reject",  callback_data: `vipreject_${data.telegramId}`  },
    ]],
  };

  try {
    if (data.screenshotPath) {
      const fs = await import("fs");
      const pathMod = await import("path");
      if (fs.existsSync(data.screenshotPath)) {
        try {
          const fileBuffer = fs.readFileSync(data.screenshotPath);
          const ext = pathMod.extname(data.screenshotPath).toLowerCase();
          const mimeType = ext === ".png" ? "image/png" : ext === ".gif" ? "image/gif" : "image/jpeg";
          const blob = new Blob([fileBuffer], { type: mimeType });
          const form = new FormData();
          form.append("chat_id", ADMIN_CHAT_ID);
          form.append("photo", blob, pathMod.basename(data.screenshotPath));
          form.append("caption", caption);
          form.append("parse_mode", "HTML");
          form.append("reply_markup", JSON.stringify(markup));
          const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendPhoto`, {
            method: "POST",
            body: form,
          });
          const result = await res.json() as any;
          if (result.ok) {
            console.log("[VIPBot] Order alert sent (photo): ok");
            return;
          }
          console.error("[VIPBot] sendPhoto failed:", JSON.stringify(result));
        } catch (photoErr) {
          console.error("[VIPBot] sendPhoto error:", photoErr);
        }
      } else {
        console.warn("[VIPBot] Screenshot path not found:", data.screenshotPath);
      }
    }

    // Fallback: send text message with buttons
    const msgResult = await apiCall("sendMessage", {
      chat_id: ADMIN_CHAT_ID,
      parse_mode: "HTML",
      text: caption,
      reply_markup: markup,
    });
    console.log("[VIPBot] Order alert sent (text):", msgResult !== null ? "ok" : "failed");
  } catch (err) {
    console.error("[VIPBot] sendOrderAlert error:", err);
  }
}

export function startVipBotPolling() {
  pollUpdates();
}

// ─── Expiry checker ───────────────────────────────────────────────────────────

export async function checkExpiredVipUsers() {
  try {
    const now = new Date();
    const activeUsers = await db.select().from(vipBotUsers).where(eq(vipBotUsers.status, "active"));

    for (const user of activeUsers) {
      if (!user.expiryDate) continue;
      const expiryTime = new Date(user.expiryDate).getTime();
      const daysLeft = Math.ceil((expiryTime - now.getTime()) / 86400000);

      if (expiryTime < now.getTime()) {
        await db.update(vipBotUsers).set({ status: "expired" }).where(eq(vipBotUsers.telegramId, user.telegramId));
        await sendMsg(user.telegramId,
          `⏰ *VIP Expired*\n\nYour VIP access has expired. Renew now to stay in the game!\n\nContact @zakarya_op or use /buy to renew.`,
          { reply_markup: { inline_keyboard: [[{ text: "🔄 Renew VIP", callback_data: "buy" }]] } }
        );
        if (ADMIN_CHAT_ID) {
          const ref = user.telegramUsername ? `@${user.telegramUsername}` : user.telegramName || user.telegramId;
          await sendMsg(ADMIN_CHAT_ID, `⏰ VIP expired: *${ref}* (\`${user.telegramId}\`)\n📦 ${PLANS[user.plan || ""]?.label || user.plan}`);
        }
      } else if (daysLeft === 3) {
        await sendMsg(user.telegramId,
          `⚠️ *VIP Expiring Soon!*\n\nYour VIP expires in *3 days*.\n\nRenew now to keep your access!`,
          { reply_markup: { inline_keyboard: [[{ text: "🔄 Renew VIP", callback_data: "buy" }]] } }
        );
      } else if (daysLeft === 1) {
        await sendMsg(user.telegramId,
          `🚨 *VIP Expires Tomorrow!*\n\nYour VIP access ends in *24 hours*.\n\nDon't lose your access — renew now!`,
          { reply_markup: { inline_keyboard: [[{ text: "🔄 Renew NOW", callback_data: "buy" }]] } }
        );
      }
    }
  } catch (err) {
    console.error("[VIPBot] Expiry check error:", err);
  }
}
